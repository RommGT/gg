const express = require('express');
const router = express.Router();
const jwt_decode = require('jwt-decode')
const db = require("../database");
const { verifyToken, isAdmin } = require('../middleware/auth');
const fileUpload = require('express-fileupload');
router.use(fileUpload());


router.get("/getChallenges", verifyToken, isAdmin, (req, res) => {
    sqlSelect = "SELECT challenge_id,name, categories.title,value,state FROM challenges INNER JOIN categories ON challenges.category_id = categories.category_id";
    db.query(sqlSelect, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result.length > 0) {
                res.send(result);
            }
            else {
                res.send([{ challenge_id: "0", name: "No hay retos disponibles", title: "Ninguna", value: "0", state: "0" }]);
            }
        }
    })
});
router.get("/getChallenge/:challenge_id", verifyToken, isAdmin, (req, res) => {
    const challenge = req.params.challenge_id;
    const sqlSelect = "SELECT * FROM challenges WHERE challenges.challenge_id = ?";
    db.query(sqlSelect, challenge, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrio un error intente mas tarde." })
            throw err;
        }
        else {
            res.send(result);
        }
    })
});
router.get("/getHintID/:hint_id", verifyToken, isAdmin, (req, res) => {
    const hint_id = req.params.hint_id;
    const sqlSelect = "SELECT * FROM hints WHERE hint_id = ?";
    db.query(sqlSelect, hint_id, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrio un error intente mas tarde." })
            throw err;
        }
        else {
            res.send(result);
        }
    })
});
router.post('/createChallenge', verifyToken, isAdmin, (req, res) => {
    const { category_id, name, description, link, value, state, flag } = req.body;
    const imageN = Math.floor(Math.random() * 32 + 1);
    const imageR = "/imgChallenge/img" + imageN + '.jpg';
    const sqlInsertChall = "INSERT INTO challenges (category_id,name,description,link,value,state,icon,flag) VALUES (?,?,?,?,?,?,?,?)";
    db.query(sqlInsertChall, [category_id, name, description, link, value, state,  imageR, flag], (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        } else {
            res.send({ messageSuccess: "Reto creado!" });
        }
    });
});

/*router.post('/uploadFile', verifyToken, isAdmin, (req, res) => {
    if (req.files === null) {
        return res.status(400).json({ msg: 'No file uploaded' });
    }

    const file = req.files.file;

    file.mv(`${__dirname}/../../frontend/public/uploadChallenges/${file.name}`, err => {
        if (err) {
            console.log(err)
            return res.status(500).send(err);
        }

        res.json({ fileName: file.name, filePath: `/uploadChallenges/${file.name}` });
    });
});*/

router.delete("/challengeDelete/:challenge_id", verifyToken, isAdmin, (req, res) => {
    const challenge = req.params.challenge_id;
    const sqlDeleteSolves = "DELETE FROM solves WHERE challenge_id=?";
    const sqlDeleteChallenge = "DELETE FROM challenges WHERE challenge_id = ?";
    db.query(sqlDeleteSolves, challenge, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrio un error intente mas tarde." });
            throw err;
        }
        else {
            db.query(sqlDeleteChallenge, challenge, (err, result) => {
                if (err) {
                    console.log(err);
                    res.send({ messageError: "Ocurrio un error intente mas tarde." });
                    throw err;
                } else {
                    res.send({ messageSuccess: "Reto eliminado!" });
                }
            });
        }
    });
});
router.delete("/hintDelete/:hint_id", verifyToken, isAdmin, (req, res) => {
    const hint = req.params.hint_id;
    const sqlDeleteSolves = "DELETE FROM openhints WHERE hint_id=?";
    const sqlDeleteChallenge = "DELETE FROM hints WHERE hint_id = ?";
    db.query(sqlDeleteSolves, hint, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrio un error intente mas tarde." });
            throw err;
        }
        else {
            db.query(sqlDeleteChallenge, hint, (err, result) => {
                if (err) {
                    console.log(err);
                    res.send({ messageError: "Ocurrio un error intente mas tarde." });
                    throw err;
                } else {
                    res.send({ messageSuccess: "Pista eliminada!" });
                }
            });
        }
    });
});
router.put("/updateChallengeState", verifyToken, isAdmin, (req, res) => {
    sqlUpdateState = "UPDATE challenges SET state=? WHERE challenge_id=?";
    const { challenge_id, state } = req.body;
    db.query(sqlUpdateState, [state, challenge_id], (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            res.send(result);
        }
    })
})
router.put("/updateChallenge", verifyToken, isAdmin, (req, res) => {
    const challenge = req.body.challenge_id;
    const name = req.body.name;
    const description = req.body.description;
    const link = req.body.link;
    const value = req.body.value;
    const flag = req.body.flag;
    const category = req.body.category;
    const sqlUpdate = "UPDATE challenges SET name= ?, description= ?, link=?,value=?,category_id=?,flag= ? WHERE challenge_id= ?";
    db.query(sqlUpdate, [name, description, link, value, category, flag, challenge], (err, result2) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrio un error intente mas tarde." })
            throw err;
        }
        else {
            res.send({ messageSuccess: "Reto actualizado!" });
        }

    });

});
router.put("/updateHint", verifyToken, isAdmin, (req, res) => {
    const hint_id = req.body.hint_id;
    const hint = req.body.hint;
    const cost = req.body.cost;
    const sqlUpdate = "UPDATE hints SET hint= ?, cost= ? WHERE hint_id= ?";
    db.query(sqlUpdate, [hint,cost,hint_id], (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrio un error intente mas tarde." })
            throw err;
        }
        else {
            res.send({ messageSuccess: "Pista actualizada!" });
        }
    });
});
router.get("/getChallengeName", verifyToken, isAdmin, (req, res) => {
    sqlSelect = "SELECT challenge_id, name FROM challenges";
    db.query(sqlSelect, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result.length > 0) {
                const list = [];
                list.push({ challenge_id: 0, name: 'Ninguno' });
                result.forEach(element => {
                    list.push({
                        challenge_id: element.challenge_id,
                        name: element.name
                    })
                });
                res.send(list);
            }
            else {
                res.send([{ challenge_id: "0", name: "Ninguno" }]);
            }
        }
    });
});
router.post("/createHint", verifyToken, isAdmin, (req, res) => {
    const { challenge_id, hint, cost } = req.body;
    const sqlInsertHint = "INSERT INTO hints (challenge_id,hint,cost) VALUES (?,?,?)";
    if (challenge_id == 0 || !hint || !cost) {
        res.send({ messageError: "Todos los campos son obligatorios!" });
    }
    else {

        db.query(sqlInsertHint, [challenge_id, hint, cost], (err, result) => {
            if (err) {
                console.log(err);
                res.send({ messageError: "Ocurrió un error intente más tarde." })
                throw err;
            }
            else {
                res.send({ messageSuccess: "Pista creada!" });
            }

        });
    }
});
router.get("/getHints", verifyToken, isAdmin, (req, res) => {
    sqlSelect = "SELECT hints.hint_id,challenges.name, hints.challenge_id, hint,cost FROM hints INNER JOIN challenges ON challenges.challenge_id = hints.challenge_id";
    db.query(sqlSelect, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result.length > 0) {
                res.send(result);
            }
            else {
                res.send([{ challenge_id: "0", hint: "No hay pistas", cost: "0" }]);
            }
        }
    });
})
module.exports = router;