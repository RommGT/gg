const express = require('express');
const router = express.Router();
const db = require("../database");
const { verifyToken, isAdmin } = require('../middleware/auth');

router.post('/createModule', verifyToken, isAdmin, (req, res) => {
    const info = req.body;
    const sqlInsert = "INSERT INTO learning (category_id,title,level,location,content,created) VALUES (?,?,?,?,?,?)";
    const sqlSelect = "SELECT * FROM learning WHERE title = ? and category_id=?";
    var num = Math.floor(Math.random() * 32 + 1);
    var location = "/imgChallenge/img" + num + ".jpg"
    const today = new Date();
    const date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    const time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    const dateTime = date + ' ' + time;
    if (!info.title || !info.type || !info.content || !info.level) { res.send({ messageError: "Todos los campos son obligatorios" }); }
    else {
        db.query(sqlSelect, [info.title, info.type], (err, result) => {
            if (err) {
                console.log(err);
                throw err
            };
            if (result.length > 0) {
                res.send({ messageError: "El módulo ya existe" })
            }
            else {
                db.query(sqlInsert, [info.type, info.title, info.level, location, info.content, dateTime], (err, result) => {
                    if (err) {
                        res.send({ messageError: "Error al ingresar la información" });
                        console.log(err);
                        throw err;
                    }
                    else {
                        res.send({ messageSuccess: "Módulo creado!" });
                    }
                })
            }
        })
    }
})
router.post('/updateModule', verifyToken, isAdmin, (req, res) => {
    const info = req.body;
    const sqlUpdate = "UPDATE learning SET category_id=?,title=?,level=?,content=? WHERE learn_id=?";
    db.query(sqlUpdate, [info.type, info.title, info.level, info.content, info.learn_id], (err, result) => {
        if (err) {
            res.send({ messageError: "Error al actualizar la información" });
            console.log(err);
            throw err;
        }
        else {
            res.send({ messageSuccess: "Módulo actualizado!" });
        }
    })

})
router.get('/getModules', verifyToken, isAdmin, (req, res) => {
    const sqlContent = "SELECT learn_id,categories.category_id, categories.title as category, learning.title as title, learning.level as level, learning.content as content FROM learning INNER JOIN categories ON learning.category_id=categories.category_id"
    db.query(sqlContent, (err, result) => {
        if (err) {
            res.send({ messageError: "Error al obtener las categorias" });
            console.log(err);
            throw err;
        }
        else {
            if (result.length > 0) {
                res.send(result);
            }
            else {
                console.log("No hay contenido")
                res.send([{ learn_id: 0, title: "No hay ningún módulo creado" }])
            }

        }
    })

})
router.post('/createFlag', verifyToken, isAdmin, (req, res) => {
    const { learn_id, question, flag, value } = req.body;
    const sqlCreate = "INSERT INTO flags (learn_id, question, flag, score) VALUES (?,?,?,?)";
    if (learn_id && question && flag && value && value != 0 & value != 'Ninguno') {
        db.query(sqlCreate, [learn_id, question, flag, value], (err, result) => {
            if (err) {
                res.send({ messageError: "Error al crear el reto!" });
                console.log(err);
                throw err;
            }
            else {
                res.send({ messageSuccess: "Reto creado!" });
            }
        })
    } else {
        res.send({ messageError: "Complete todos los campos!" });
    }
});

router.get('/getTitleContent', verifyToken, isAdmin, (req, res) => {
    const sqlTitle = "SELECT learn_id, title FROM learning";
    db.query(sqlTitle, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al obtener el titulo" });
            throw err;
        }
        else {
            if (result.length > 0) {
                const list = [];
                list.push({ learn_id: 0, title: 'Ninguno' });
                result.forEach(element => {
                    list.push({
                        learn_id: element.learn_id,
                        title: element.title
                    })
                });
                res.send(list);
            }
            else {
                res.send([{ learn_id: 0, title: " Ninguno" }]);
            }
        }
    })
});

router.delete("/deleteModule/:id", verifyToken, isAdmin, (req, res) => {
    const id = req.params.id;
    const sqlDelete = "DELETE FROM learning WHERE learn_id=?"
    db.query(sqlDelete, id, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al eliminar el módulo" });
            throw err;
        }
        else {
            res.send({ messageSuccess: "Contenido Eliminado" });
        }
    })

});

router.get('/getFlags', verifyToken, isAdmin, (req, res) => {
    const sqlFlags = "SELECT flags.flag_id,learning.title, flags.question, flags.flag, flags.score FROM flags INNER JOIN learning ON flags.learn_id = learning.learn_id";
    db.query(sqlFlags, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al obtener los retos" });
        }
        else {
            if (result.length > 0) {
                res.send(result);
            }
            else {
                res.send([{ title: " No hay retos disponibles" }]);
            }
        }
    })
});
router.delete("/deleteFlag/:id", verifyToken, isAdmin, (req, res) => {
    const id = req.params.id;
    const sqlDelete = "DELETE FROM flags WHERE flag_id=?"
    db.query(sqlDelete, id, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al eliminar el reto" });
            throw err;
        }
        res.send({ messageSuccess: "Contenido Eliminado" });
    })

});

router.post("/getFlag", verifyToken, isAdmin, (req, res) => {
    const flag_id = req.body.flag_id;
    
    const sqlFlag = "SELECT * FROM flags WHERE flag_id = ?";
    db.query(sqlFlag, flag_id, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al obtener el reto" });
            throw err;
        }
        else {
            res.send(result);
        }
    })
})

router.put('/updateFlag', verifyToken, isAdmin, (req, res) => {
    const sqlUpdate = "UPDATE flags SET question=?,flag=?, score=? WHERE flag_id=? "
    const { question, flag, score, flag_id } = req.body;
    db.query(sqlUpdate, [question, flag, score, flag_id], (err, result) => {
        if (err) {
            console.log(err);
            res.status(500).send({
                messageError: "Error al actualizar el reto"
            })
        }
        else {
            res.status(200).send({
                messageSuccess: "Reto actualizado!"
            })
        }
    });
});
router.post('/createQuiz', verifyToken, isAdmin, (req, res) => {
    const { question, level, answer1, answer2, answer3, answer4, correctAnswer } = req.body;
    const today = new Date();
    const date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    const time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    const dateTime = date + ' ' + time;
    const sqlCreate = "INSERT INTO quiz (question,level,answers,correctAnswer,created) VALUES (?,?,?,?,?)";
    if (question && answer1 && answer2 && answer3 && answer4 && level && correctAnswer) {
        const answers = [answer1, answer2, answer3, answer4];
        db.query(sqlCreate, [question, level, answers.toString(), correctAnswer, dateTime], (err, result) => {
            if (err) {
                console.log(err);
                res.send({ messageError: "Error al registrar la pregunta" });
                throw err;
            }
            else {
                res.send({
                    messageSuccess: "Pregunta ingresada!"
                });
            }
        })
    } else {
        res.send({ messageError: "Complete todos los campos!" });
    }
});

router.get('/getQuiz', verifyToken, isAdmin, (req, res) => {
    const sqlQuiz = "SELECT question_id,question, level from quiz";
    db.query(sqlQuiz, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al obtener los retos" });
        }
        else {
            if (result.length > 0) {
                res.send(result);
            }
            else {
                res.send([{ question: " No hay preguntas disponibles" }]);
            }
        }
    })
});
router.delete("/deleteQuiz/:id", verifyToken, isAdmin, (req, res) => {
    const id = req.params.id;
    const sqlDelete = "DELETE FROM quiz WHERE question_id=?"
    const sqlLevel = "SELECT level FROM quiz WHERE question_id=?"
    const sqlQuiz = "SELECT * FROM quiz WHERE level=?"
    db.query(sqlLevel, id, (err, result) => {
        if (err) {
            res.send({ messageError: "Error al eliminar la pregunta" });
            console.log(err)
            throw err;
        }
        else {
            db.query(sqlDelete, id, (err, result1) => {
                if (err) {
                    console.log(err)
                    res.send({ messageError: "Error al eliminar la pregunta" });
                    throw err;
                }
                else {
                    db.query(sqlQuiz, result[0].level, (err, result2) => {
                        if (err) {
                            console.log(err)
                            res.send({ messageError: "Error al eliminar la pregunta" });
                            throw err;
                        }
                        else {
                            if (result2.length < 5) {
                                if (result[0].level == 'Inicial') {
                                    db.query("UPDATE settings set showQuizP='false'", (err, resultP) => {
                                        if (err) {
                                            console.log(err)
                                            res.send({ messageError: "Error al eliminar la pregunta" });
                                            throw err;
                                        }
                                        else {
                                            res.send({ messageSuccess: 'Pregunta eliminada', showP: true });
                                        }
                                    });
                                }
                                else if (result[0].level == 'Fácil') {
                                    db.query("UPDATE settings set showQuizF='false'", (err, resultF) => {
                                        if (err) {
                                            console.log(err)
                                            res.send({ messageError: "Error al eliminar la pregunta" });
                                            throw err;
                                        }
                                        else {
                                            res.send({ messageSuccess: 'Pregunta eliminada', showF: true })
                                        }
                                    });

                                }
                                else if (result[0].level == 'Intermedio') {
                                    db.query("UPDATE settings set showQuizM='false'", (err, resultM) => {
                                        if (err) {
                                            console.log(err)
                                            res.send({ messageError: "Error al eliminar la pregunta" });
                                            throw err;
                                        }
                                        else {
                                            res.send({ messageSuccess: 'Pregunta eliminada', showM: true })
                                        }
                                    });

                                }
                                else if (result[0].level == 'Difícil') {
                                    db.query("UPDATE settings set showQuizD='false'", (err, resultD) => {
                                        if (err) {
                                            console.log(err)
                                            res.send({ messageError: "Error al eliminar la pregunta" });
                                            throw err;
                                        }
                                        else {
                                            res.send({ messageSuccess: 'Pregunta eliminada', showD: true })
                                        }
                                    });
                                }
                            }
                            else {
                                res.send({ messageSuccess: 'Pregunta eliminada' })

                            }
                        }

                    })
                }

            })
        }
    })


});
router.post("/getQuestion", verifyToken, isAdmin, (req, res) => {
    const question_id = req.body.question_id;
    const sqlQuestion = "SELECT question_id, question, answers, correctAnswer FROM quiz WHERE question_id = ?";
    db.query(sqlQuestion, question_id, (err, result) => {
        if (err) {
            console.log(err)
            res.send({ messageError: "Error al obtener pregunta" });
            throw err;
        }
        else {
            answers = result[0].answers.split(',');
            res.send([{
                question_id: result[0].question_id, question: result[0].question,
                correctAnswer: result[0].correctAnswer, answer1: answers[0],
                answer2: answers[1], answer3: answers[2], answer4: answers[3]
            }]);
        }
    })
})
router.put('/updateQuiz', verifyToken, isAdmin, (req, res) => {
    const sqlUpdate = "UPDATE quiz SET question=?,answers=?, correctAnswer=? WHERE question_id=? "
    const { question, answer1, answer2, answer3, answer4, correctAnswer, question_id } = req.body;
    const answers = [answer1, answer2, answer3, answer4];
    db.query(sqlUpdate, [question, answers.toString(), correctAnswer, question_id], (err, result) => {
        if (err) {
            console.log(err)
            res.status(500).send({
                messageError: "Error al actualizar la pregunta"
            })
        }
        else {
            res.status(200).send({
                messageSuccess: "Pregunta actualizada!"
            })
        }
    });
});
router.get('/deleteQuizP', verifyToken, isAdmin, (req, res) => {
    const sqlQuiz = "DELETE FROM solvesQuiz WHERE level='Inicial'";
    db.query(sqlQuiz, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al reiniciar" });
        }
        else {
            res.send({ messageSuccess: 'Se reinicio correctamente!' })
        }
    })
});
router.get('/deleteQuizF', verifyToken, isAdmin, (req, res) => {
    const sqlQuiz = "DELETE FROM solvesQuiz WHERE level='Fácil'";
    db.query(sqlQuiz, (err, result) => {
        if (err) {
            res.send({ messageError: "Error al reiniciar" });
        }
        else {
            res.send({ messageSuccess: 'Se reinicio correctamente!' })
        }
    })
});
router.get('/deleteQuizM', verifyToken, isAdmin, (req, res) => {
    const sqlQuiz = "DELETE FROM solvesQuiz WHERE level='Intermedio'";
    db.query(sqlQuiz, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al reiniciar" });
        }
        else {
            res.send({ messageSuccess: 'Se reinicio correctamente!' })
        }
    })
});
router.get('/deleteQuizD', verifyToken, isAdmin, (req, res) => {
    const sqlQuiz = "DELETE FROM solvesQuiz WHERE level='Difícil'";
    db.query(sqlQuiz, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al reiniciar" });
        }
        else {
            res.send({ messageSuccess: 'Se reinicio correctamente!' })
        }
    })
});
router.post("/updateP", verifyToken, isAdmin, (req, res) => {
    const showP = req.body.showP;
    const updateQuiz = "UPDATE settings SET showQuizP=?";
    const sqlSelectQuestion = "SELECT * from quiz WHERE level='Inicial'"

    db.query(sqlSelectQuestion, (err, result1) => {
        if (err) {
            console.log(err)
            res.send({ messageError: "Error al actualizar" });
            throw err;
        }
        else {
            if (result1.length < 5) {
                res.send({ messageError: "Debe crear minimo 5 preguntas  para activar" });
            }
            else {
                db.query(updateQuiz, showP ? 'false' : 'true', (err, result2) => {
                    if (err) {
                        console.log(err)
                        res.send({ messageError: "Error al actualizar" });
                        throw err;
                    }
                    else {
                        res.send({ messageSuccess: "Actualizado correctamente!" });
                    }
                })
            }
        }
    })

})
router.post("/updateF", verifyToken, isAdmin, (req, res) => {
    const showF = req.body.showF;
    const updateQuiz = "UPDATE settings SET showQuizF=?";
    const sqlSelectQuestion = "SELECT * from quiz WHERE level='Fácil'"
    const sqlModules = "SELECT learning.learn_id FROM flags INNER JOIN learning ON flags.learn_id= learning.learn_id WHERE learning.level='Fácil';"
    db.query(sqlModules, (err, result0) => {
        if (err) {
            console.log(err)
            res.send({ messageError: "Error al actualizar" });
            throw err;
        }
        else {
            if (result0.length < 5) {
                res.send({ messageError: "Debe crear minimo 5 retos de aprendizaje  para activar" });
            }
            else {
                db.query(sqlSelectQuestion, (err, result1) => {
                    if (err) {
                        console.log(err)
                        res.send({ messageError: "Error al actualizar" });
                        throw err;
                    }
                    else {
                        if (result1.length < 5) {
                            res.send({ messageError: "Debe crear minimo 5 preguntas  para activar" });
                        }
                        else {
                            db.query(updateQuiz, showF ? 'false' : 'true', (err, result2) => {
                                if (err) {
                                    console.log(err)
                                    res.send({ messageError: "Error al actualizar" });
                                    throw err;
                                } else {
                                    res.send({ messageSuccess: "Actualizado correctamente!" });
                                }
                            });
                        }
                    }
                })
            }
        }
    })
})
router.post("/updateM", verifyToken, isAdmin, (req, res) => {
    const showM = req.body.showM;
    const updateQuiz = "UPDATE settings SET showQuizM=?";
    const sqlSelectQuestion = "SELECT * from quiz WHERE level='Intermedio'"
    const sqlModules = "SELECT learning.learn_id FROM flags INNER JOIN learning ON flags.learn_id= learning.learn_id WHERE learning.level='Intermedio';"
    db.query(sqlModules, (err, result0) => {
        if (err) {
            console.log(err)
            res.send({ messageError: "Error al actualizar" });
            throw err;
        }
        else {
            if (result0.length < 5) {
                res.send({ messageError: "Debe crear minimo 5 retos de aprendizaje  para activar" });
            }
            else {
                db.query(sqlSelectQuestion, (err, result1) => {
                    if (err) {
                        console.log(err)
                        res.send({ messageError: "Error al actualizar" });
                        throw err;
                    }
                    else {
                        if (result1.length < 5) {
                            res.send({ messageError: "Debe crear minimo 5 preguntas  para activar" });
                        }
                        else {
                            db.query(updateQuiz, showM ? 'false' : 'true', (err, result2) => {
                                if (err) {
                                    console.log(err)
                                    res.send({ messageError: "Error al actualizar" });
                                    throw err;
                                } else {
                                    res.send({ messageSuccess: "Actualizado correctamente!" });
                                }
                            });
                        }
                    }
                })

            }
        }
    })

})
router.post("/updateD", verifyToken, isAdmin, (req, res) => {
    const showD = req.body.showD;
    const updateQuiz = "UPDATE settings SET showQuizD=?";
    const sqlSelectQuestion = "SELECT * from quiz WHERE level='Difícil'"
    const sqlModules = "SELECT learning.learn_id FROM flags INNER JOIN learning ON flags.learn_id= learning.learn_id WHERE learning.level='Difícil';"
    db.query(sqlModules, (err, result0) => {
        if (err) {
            console.log(err)
            res.send({ messageError: "Error al actualizar" });
            throw err;
        }
        else {
            if (result0.length < 5) {
                res.send({ messageError: "Debe crear minimo 5 retos de aprendizaje  para activar" });
            }
            else {
                db.query(sqlSelectQuestion, (err, result1) => {
                    if (err) {
                        console.log(err)
                        res.send({ messageError: "Error al actualizar" });
                        throw err;
                    }
                    else {
                        if (result1.length < 5) {
                            res.send({ messageError: "Debe crear minimo 5 preguntas  para activar" });
                        }
                        else {
                            db.query(updateQuiz, showD ? 'false' : 'true', (err, result2) => {
                                if (err) {
                                    console.log(err)
                                    res.send({ messageError: "Error al actualizar" });
                                    throw err;
                                } else {
                                    res.send({ messageSuccess: "Actualizado correctamente!" });
                                }
                            });
                        }
                    }
                })
            }
        }
    })

})
module.exports = router;
