
const express = require('express');
const router = express.Router();
const jwt_decode = require('jwt-decode')
const { verifyToken } = require('../middleware/auth');
const db = require("../database");

router.get('/getCategories',verifyToken, (req, res) => {

    const user = jwt_decode(req.headers['authorization'])
    const sqlSettings = 'SELECT showQuizP,showQuizF,showQuizM,showQuizD FROM settings'
    const sqlCategories = "SELECT * FROM categories";
    const sqlModules = 'select categories.title, COUNT(categories.title) as numM from learning INNER JOIN categories ON learning.category_id=categories.category_id GROUP BY categories.title;'
    const sqlSolvesQuizPre = "SELECT * FROM solvesQuiz WHERE (user_id=? AND level='Inicial')";
    const sqlSelectQuizPre = "SELECT question_id,question,level,answers FROM quiz WHERE level='Inicial'";
    const sqlSolvesQuizF = "SELECT * FROM solvesQuiz WHERE user_id=? and level='Fácil'";
    const sqlSelectQuizF = "SELECT question_id,question,level,answers FROM quiz WHERE level='Fácil'";
    const sqlSolvesQuizM = "SELECT * FROM solvesQuiz WHERE user_id=? and level='Intermedio'";
    const sqlSelectQuizM = "SELECT question_id,question,level,answers FROM quiz WHERE level='Intermedio'";
    const sqlSolvesQuizD = "SELECT * FROM solvesQuiz WHERE user_id=? and level='Difícil'";
    const sqlSelectQuizD = "SELECT question_id,question,level,answers FROM quiz WHERE level='Difícil'";
    const sqlSolvesLearnF = "SELECT COUNT(solvesLearn.solvesLearn_id) as countF FROM solvesLearn INNER JOIN flags ON solvesLearn.flag_id=flags.flag_id INNER JOIN learning ON flags.learn_id=learning.learn_id WHERE solvesLearn.user_id=? and learning.level='Fácil'"
    const sqlLearnFTotal = "SELECT COUNT(learning.learn_id) AS countTotalF FROM flags INNER JOIN learning ON flags.learn_id=learning.learn_id WHERE learning.level='Fácil'";
    const sqlSolvesLearnM = "SELECT COUNT(solvesLearn.solvesLearn_id) as countM FROM solvesLearn INNER JOIN flags ON solvesLearn.flag_id=flags.flag_id INNER JOIN learning ON flags.learn_id=learning.learn_id WHERE solvesLearn.user_id=? and learning.level='Intermedio'"
    const sqlLearnMTotal = "SELECT COUNT(learning.learn_id) AS countTotalM FROM flags INNER JOIN learning ON flags.learn_id=learning.learn_id WHERE learning.level='Intermedio'";
    const sqlSolvesLearnD = "SELECT COUNT(solvesLearn.solvesLearn_id) as countD FROM solvesLearn INNER JOIN flags ON solvesLearn.flag_id=flags.flag_id INNER JOIN learning ON flags.learn_id=learning.learn_id WHERE solvesLearn.user_id=? and learning.level='Difícil'"
    const sqlLearnDTotal = "SELECT COUNT(learning.learn_id) AS countTotalD FROM flags INNER JOIN learning ON flags.learn_id=learning.learn_id WHERE learning.level='Difícil'";

    db.query(sqlSettings, (err, resultSettings) => {
        if (err) {
            console.log(err)
            throw err;
        }
        else {
            db.query(sqlModules, (err, resultModule) => {
                if (err) {
                    console.log(err);
                    throw err;
                }
                else {
                    db.query(sqlCategories, (err, resultCategories) => {
                        if (err) {
                            console.log(err)
                            throw err;
                        }
                        else {
                            db.query(sqlSolvesQuizPre, [user.id], (err, resultPre) => {
                                if (err) {
                                    res.send({ messageError: "Error al obtener las categorías" });
                                    console.log(err)
                                    throw err;
                                }
                                else {
                                    if (resultPre.length > 0) {
                                        db.query(sqlLearnFTotal, (err, resultFacilTotal) => {
                                            if (err) {
                                                res.send({ messageError: "Error al obtener las categorías" });
                                                console.log(err)
                                                throw err;
                                            }
                                            else {
                                                db.query(sqlSolvesLearnF, [user.id], (err, resultFacil) => {
                                                    if (err) {
                                                        res.send({ messageError: "Error al obtener las categorías" });
                                                        console.log(err)
                                                        throw err;
                                                    }
                                                    else {
                                                        db.query(sqlLearnMTotal, (err, resultMedioTotal) => {
                                                            if (err) {
                                                                res.send({ messageError: "Error al obtener las categorías" });
                                                                console.log(err)
                                                                throw err;
                                                            }
                                                            else {
                                                                db.query(sqlSolvesLearnM, [user.id], (err, resultMedio) => {
                                                                    if (err) {
                                                                        res.send({ messageError: "Error al obtener las categorías" });
                                                                        console.log(err)
                                                                        throw err;
                                                                    }
                                                                    else {
                                                                        db.query(sqlLearnDTotal, (err, resultDificilTotal) => {
                                                                            if (err) {
                                                                                res.send({ messageError: "Error al obtener las categorías" });
                                                                                console.log(err)
                                                                                throw err;
                                                                            }
                                                                            else {
                                                                                db.query(sqlSolvesLearnD, [user.id], (err, resultDificil) => {
                                                                                    if (err) {
                                                                                        res.send({ messageError: "Error al obtener las categorías" });
                                                                                        console.log(err)
                                                                                        throw err;
                                                                                    }
                                                                                    else {
                                                                                        if (resultFacil.length > 0) {

                                                                                            if (resultFacilTotal[0].countTotalF == resultFacil[0].countF) {

                                                                                                if (resultSettings[0].showQuizF == 'true') {

                                                                                                    db.query(sqlSolvesQuizF, [user.id], (err, resultQuizF) => {
                                                                                                        if (err) {
                                                                                                            res.send({ messageError: "Error al obtener la encuesta" });
                                                                                                            console.log(err)
                                                                                                            throw err;
                                                                                                        } else {
                                                                                                            if (resultQuizF.length > 0) {
                                                                                                                if (resultModule.length > 0) {
                                                                                                                    let resultModCategories=[];
                                                                                                                    for (let i = 0; i < resultCategories.length; i++) {
                                                                                                                        let modules=0;
                                                                                                                        for (let j = 0; j < resultModule.length; j++) {
                                                                                                                            if(resultCategories[i].title==resultModule[j].title){
                                                                                                                                modules=resultModule[j].numM;
                                                                                                                                break;
                                                                                                                            }
                                                                                                                        }
                                                                                                                        resultModCategories.push({category_id:resultCategories[i].category_id,title:resultCategories[i].title,description:resultCategories[i].description,location:resultCategories[i].location,modules:modules})
                                                                                                                    }
                                                                                                                    res.send({ categories: resultModCategories, showQuiz: false })
                                                                                                                }
                                                                                                                else {
                                                                                                                    res.send({ categories: resultCategories, showQuiz: false })
                                                                                                                }

                                                                                                            }
                                                                                                            else {
                                                                                                                db.query(sqlSelectQuizF, (err, quizF) => {
                                                                                                                    if (err) {
                                                                                                                        res.send({ messageError: "Error al obtener la encuesta" });
                                                                                                                        console.log(err)
                                                                                                                        throw err;
                                                                                                                    } else {
                                                                                                                        let quizArray = [];
                                                                                                                        for (var i = 0; i < 5; i++) {
                                                                                                                            const number = Math.floor(Math.random() * quizF.length);
                                                                                                                            let exist = false;
                                                                                                                            for (var j = 0; j < quizArray.length; j++) {
                                                                                                                                if (number == quizArray[j]) {
                                                                                                                                    exist = true;
                                                                                                                                    break;
                                                                                                                                }

                                                                                                                            }
                                                                                                                            if (exist) {
                                                                                                                                i--;
                                                                                                                            }
                                                                                                                            else {
                                                                                                                                quizArray.push(number);
                                                                                                                            }
                                                                                                                        }

                                                                                                                        const quizF1 = [{ question_id: quizF[quizArray[0]].question_id, question: quizF[quizArray[0]].question, level: quizF[quizArray[0]].level, answers: quizF[quizArray[0]].answers },
                                                                                                                        { question_id: quizF[quizArray[1]].question_id, question: quizF[quizArray[1]].question, level: quizF[quizArray[1]].level, answers: quizF[quizArray[1]].answers },
                                                                                                                        { question_id: quizF[quizArray[2]].question_id, question: quizF[quizArray[2]].question, level: quizF[quizArray[2]].level, answers: quizF[quizArray[2]].answers },
                                                                                                                        { question_id: quizF[quizArray[3]].question_id, question: quizF[quizArray[3]].question, level: quizF[quizArray[3]].level, answers: quizF[quizArray[3]].answers },
                                                                                                                        { question_id: quizF[quizArray[4]].question_id, question: quizF[quizArray[4]].question, level: quizF[quizArray[4]].level, answers: quizF[quizArray[4]].answers },];
                                                                                                                        res.send({ quiz: quizF1, showQuiz: true })
                                                                                                                    }
                                                                                                                });
                                                                                                            }

                                                                                                        }
                                                                                                    });
                                                                                                }
                                                                                                else {
                                                                                                    if (resultModule.length > 0) {
                                                                                                        let resultModCategories=[];
                                                                                                        for (let i = 0; i < resultCategories.length; i++) {
                                                                                                            let modules=0;
                                                                                                            for (let j = 0; j < resultModule.length; j++) {
                                                                                                                if(resultCategories[i].title==resultModule[j].title){
                                                                                                                    modules=resultModule[j].numM;
                                                                                                                    break;
                                                                                                                }
                                                                                                            }
                                                                                                            resultModCategories.push({category_id:resultCategories[i].category_id,title:resultCategories[i].title,description:resultCategories[i].description,location:resultCategories[i].location,modules:modules})
                                                                                                        }
                                                                                                        res.send({ categories: resultModCategories, showQuiz: false })
                                                                                                    }
                                                                                                    else {
                                                                                                        res.send({ categories: resultCategories, showQuiz: false })
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                            else {
                                                                                                if (resultModule.length > 0) {
                                                                                                    let resultModCategories=[];
                                                                                                    for (let i = 0; i < resultCategories.length; i++) {
                                                                                                        let modules=0;
                                                                                                        for (let j = 0; j < resultModule.length; j++) {
                                                                                                            if(resultCategories[i].title==resultModule[j].title){
                                                                                                                modules=resultModule[j].numM;
                                                                                                                break;
                                                                                                            }
                                                                                                        }
                                                                                                        resultModCategories.push({category_id:resultCategories[i].category_id,title:resultCategories[i].title,description:resultCategories[i].description,location:resultCategories[i].location,modules:modules})
                                                                                                    }
                                                                                                    res.send({ categories: resultModCategories, showQuiz: false })
                                                                                                }
                                                                                                else {
                                                                                                    res.send({ categories: resultCategories, showQuiz: false })
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                        else if (resultMedio.length > 0) {
                                                                                            if (resultMedioTotal[0].countTotalM == resultMedio[0].countM) {
                                                                                                if (resultSettings[0].showQuizM == 'true') {
                                                                                                    db.query(sqlSolvesQuizM, [user.id], (err, resultQuizM) => {
                                                                                                        if (err) {
                                                                                                            res.send({ messageError: "Error al obtener la encuesta" });
                                                                                                            console.log(err)
                                                                                                            throw err;
                                                                                                        } else {
                                                                                                            if (resultQuizM.length > 0) {
                                                                                                                if (resultModule.length > 0) {
                                                                                                                    let resultModCategories=[];
                                                                                                                    for (let i = 0; i < resultCategories.length; i++) {
                                                                                                                        let modules=0;
                                                                                                                        for (let j = 0; j < resultModule.length; j++) {
                                                                                                                            if(resultCategories[i].title==resultModule[j].title){
                                                                                                                                modules=resultModule[j].numM;
                                                                                                                                break;
                                                                                                                            }
                                                                                                                        }
                                                                                                                        resultModCategories.push({category_id:resultCategories[i].category_id,title:resultCategories[i].title,description:resultCategories[i].description,location:resultCategories[i].location,modules:modules})
                                                                                                                    }
                                                                                                                    res.send({ categories: resultModCategories, showQuiz: false })
                                                                                                                }
                                                                                                                else {
                                                                                                                    res.send({ categories: resultCategories, showQuiz: false })
                                                                                                                }
                                                                                                            }
                                                                                                            else {
                                                                                                                db.query(sqlSelectQuizM, (err, quizM) => {
                                                                                                                    if (err) {
                                                                                                                        res.send({ messageError: "Error al obtener la encuesta" });
                                                                                                                        console.log(err)
                                                                                                                        throw err;
                                                                                                                    } else {
                                                                                                                        let quizArray = [];
                                                                                                                        for (var i = 0; i < 5; i++) {
                                                                                                                            const number = Math.floor(Math.random() * quizM.length);
                                                                                                                            let exist = false;
                                                                                                                            for (var j = 0; j < quizArray.length; j++) {
                                                                                                                                if (number == quizArray[j]) {
                                                                                                                                    exist = true;
                                                                                                                                    break;
                                                                                                                                }

                                                                                                                            }
                                                                                                                            if (exist) {
                                                                                                                                i--;
                                                                                                                            }
                                                                                                                            else {
                                                                                                                                quizArray.push(number);
                                                                                                                            }
                                                                                                                        }

                                                                                                                        const quizM1 = [{ question_id: quizM[quizArray[0]].question_id, question: quizM[quizArray[0]].question, level: quizM[quizArray[0]].level, answers: quizM[quizArray[0]].answers },
                                                                                                                        { question_id: quizM[quizArray[1]].question_id, question: quizM[quizArray[1]].question, level: quizM[quizArray[1]].level, answers: quizM[quizArray[1]].answers },
                                                                                                                        { question_id: quizM[quizArray[2]].question_id, question: quizM[quizArray[2]].question, level: quizM[quizArray[2]].level, answers: quizM[quizArray[2]].answers },
                                                                                                                        { question_id: quizM[quizArray[3]].question_id, question: quizM[quizArray[3]].question, level: quizM[quizArray[3]].level, answers: quizM[quizArray[3]].answers },
                                                                                                                        { question_id: quizM[quizArray[4]].question_id, question: quizM[quizArray[4]].question, level: quizM[quizArray[4]].level, answers: quizM[quizArray[4]].answers },];
                                                                                                                        res.send({ quiz: quizM1, showQuiz: true })
                                                                                                                    }
                                                                                                                });
                                                                                                            }

                                                                                                        }
                                                                                                    });
                                                                                                }
                                                                                                else {
                                                                                                    if (resultModule.length > 0) {
                                                                                                        let resultModCategories=[];
                                                                                                        for (let i = 0; i < resultCategories.length; i++) {
                                                                                                            let modules=0;
                                                                                                            for (let j = 0; j < resultModule.length; j++) {
                                                                                                                if(resultCategories[i].title==resultModule[j].title){
                                                                                                                    modules=resultModule[j].numM;
                                                                                                                    break;
                                                                                                                }
                                                                                                            }
                                                                                                            resultModCategories.push({category_id:resultCategories[i].category_id,title:resultCategories[i].title,description:resultCategories[i].description,location:resultCategories[i].location,modules:modules})
                                                                                                        }
                                                                                                        res.send({ categories: resultModCategories, showQuiz: false })
                                                                                                    }
                                                                                                    else {
                                                                                                        res.send({ categories: resultCategories, showQuiz: false })
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                            else {
                                                                                                if (resultModule.length > 0) {
                                                                                                    let resultModCategories=[];
                                                                                                    for (let i = 0; i < resultCategories.length; i++) {
                                                                                                        let modules=0;
                                                                                                        for (let j = 0; j < resultModule.length; j++) {
                                                                                                            if(resultCategories[i].title==resultModule[j].title){
                                                                                                                modules=resultModule[j].numM;
                                                                                                                break;
                                                                                                            }
                                                                                                        }
                                                                                                        resultModCategories.push({category_id:resultCategories[i].category_id,title:resultCategories[i].title,description:resultCategories[i].description,location:resultCategories[i].location,modules:modules})
                                                                                                    }
                                                                                                    res.send({ categories: resultModCategories, showQuiz: false })
                                                                                                }
                                                                                                else {
                                                                                                    res.send({ categories: resultCategories, showQuiz: false })
                                                                                                }
                                                                                            }

                                                                                        }
                                                                                        else if (resultDificil.length > 0) {
                                                                                            if (resultDificilTotal[0].countTotalD == resultDificil[0].countD) {
                                                                                                if (resultSettings[0].showQuizD == 'true') {
                                                                                                    db.query(sqlSolvesQuizD, [user.id], (err, resultQuizD) => {
                                                                                                        if (err) {
                                                                                                            res.send({ messageError: "Error al obtener la encuesta" });
                                                                                                            console.log(err)
                                                                                                            throw err;
                                                                                                        } else {
                                                                                                            if (resultQuizD.length > 0) {
                                                                                                                if (resultModule.length > 0) {
                                                                                                                    let resultModCategories=[];
                                                                                                                    for (let i = 0; i < resultCategories.length; i++) {
                                                                                                                        let modules=0;
                                                                                                                        for (let j = 0; j < resultModule.length; j++) {
                                                                                                                            if(resultCategories[i].title==resultModule[j].title){
                                                                                                                                modules=resultModule[j].numM;
                                                                                                                                break;
                                                                                                                            }
                                                                                                                        }
                                                                                                                        resultModCategories.push({category_id:resultCategories[i].category_id,title:resultCategories[i].title,description:resultCategories[i].description,location:resultCategories[i].location,modules:modules})
                                                                                                                    }
                                                                                                                    res.send({ categories: resultModCategories, showQuiz: false })
                                                                                                                }
                                                                                                                else {
                                                                                                                    res.send({ categories: resultCategories, showQuiz: false })
                                                                                                                }
                                                                                                            } else {
                                                                                                                db.query(sqlSelectQuizD, (err, quizD) => {
                                                                                                                    if (err) {
                                                                                                                        res.send({ messageError: "Error al obtener la encuesta" });
                                                                                                                        console.log(err)
                                                                                                                        throw err;
                                                                                                                    } else {
                                                                                                                        let quizArray = [];
                                                                                                                        for (var i = 0; i < 5; i++) {
                                                                                                                            const number = Math.floor(Math.random() * quizD.length);
                                                                                                                            let exist = false;
                                                                                                                            for (var j = 0; j < quizArray.length; j++) {
                                                                                                                                if (number == quizArray[j]) {
                                                                                                                                    exist = true;
                                                                                                                                    break;
                                                                                                                                }

                                                                                                                            }
                                                                                                                            if (exist) {
                                                                                                                                i--;
                                                                                                                            }
                                                                                                                            else {
                                                                                                                                quizArray.push(number);
                                                                                                                            }
                                                                                                                        }

                                                                                                                        const quizD1 = [{ question_id: quizD[quizArray[0]].question_id, question: quizD[quizArray[0]].question, level: quizD[quizArray[0]].level, answers: quizD[quizArray[0]].answers },
                                                                                                                        { question_id: quizD[quizArray[1]].question_id, question: quizD[quizArray[1]].question, level: quizD[quizArray[1]].level, answers: quizD[quizArray[1]].answers },
                                                                                                                        { question_id: quizD[quizArray[2]].question_id, question: quizD[quizArray[2]].question, level: quizD[quizArray[2]].level, answers: quizD[quizArray[2]].answers },
                                                                                                                        { question_id: quizD[quizArray[3]].question_id, question: quizD[quizArray[3]].question, level: quizD[quizArray[3]].level, answers: quizD[quizArray[3]].answers },
                                                                                                                        { question_id: quizD[quizArray[4]].question_id, question: quizD[quizArray[4]].question, level: quizD[quizArray[4]].level, answers: quizD[quizArray[4]].answers },];
                                                                                                                        res.send({ quiz: quizD1, showQuiz: true })
                                                                                                                    }
                                                                                                                });
                                                                                                            }
                                                                                                        }
                                                                                                    });
                                                                                                }
                                                                                                else {
                                                                                                    if (resultModule.length > 0) {
                                                                                                        let resultModCategories=[];
                                                                                                        for (let i = 0; i < resultCategories.length; i++) {
                                                                                                            let modules=0;
                                                                                                            for (let j = 0; j < resultModule.length; j++) {
                                                                                                                if(resultCategories[i].title==resultModule[j].title){
                                                                                                                    modules=resultModule[j].numM;
                                                                                                                    break;
                                                                                                                }
                                                                                                            }
                                                                                                            resultModCategories.push({category_id:resultCategories[i].category_id,title:resultCategories[i].title,description:resultCategories[i].description,location:resultCategories[i].location,modules:modules})
                                                                                                        }
                                                                                                        res.send({ categories: resultModCategories, showQuiz: false })
                                                                                                    }
                                                                                                    else {
                                                                                                        res.send({ categories: resultCategories, showQuiz: false })
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                            else {
                                                                                                if (resultModule.length > 0) {
                                                                                                    let resultModCategories=[];
                                                                                                    for (let i = 0; i < resultCategories.length; i++) {
                                                                                                        let modules=0;
                                                                                                        for (let j = 0; j < resultModule.length; j++) {
                                                                                                            if(resultCategories[i].title==resultModule[j].title){
                                                                                                                modules=resultModule[j].numM;
                                                                                                                break;
                                                                                                            }
                                                                                                        }
                                                                                                        resultModCategories.push({category_id:resultCategories[i].category_id,title:resultCategories[i].title,description:resultCategories[i].description,location:resultCategories[i].location,modules:modules})
                                                                                                    }
                                                                                                    res.send({ categories: resultModCategories, showQuiz: false })
                                                                                                }
                                                                                                else {
                                                                                                    res.send({ categories: resultCategories, showQuiz: false })
                                                                                                }
                                                                                            }

                                                                                        }
                                                                                        else {
                                                                                            if (resultModule.length > 0) {
                                                                                                let resultModCategories=[];
                                                                                                for (let i = 0; i < resultCategories.length; i++) {
                                                                                                    let modules=0;
                                                                                                    for (let j = 0; j < resultModule.length; j++) {
                                                                                                        if(resultCategories[i].title==resultModule[j].title){
                                                                                                            modules=resultModule[j].numM;
                                                                                                            break;
                                                                                                        }
                                                                                                    }
                                                                                                    resultModCategories.push({category_id:resultCategories[i].category_id,title:resultCategories[i].title,description:resultCategories[i].description,location:resultCategories[i].location,modules:modules})
                                                                                                }
                                                                                                
                                                                                                res.send({ categories: resultModCategories, showQuiz: false })
                                                                                            }
                                                                                            else {
                                                                                                res.send({ categories: resultCategories, showQuiz: false })
                                                                                            }
                                                                                        }

                                                                                    }
                                                                                })
                                                                            }
                                                                        })

                                                                    }
                                                                })

                                                            }
                                                        })

                                                    }
                                                })

                                            }
                                        })


                                    }
                                    else {
                                        if (resultSettings[0].showQuizP == 'true') {
                                            db.query(sqlSelectQuizPre, (err, resultShowPre) => {
                                                if (err) {
                                                    console.log(err)
                                                    res.send({ messageError: "Error al obtener el quiz" });
                                                }
                                                else {
                                                    let quizArray = [];
                                                    for (var i = 0; i < 5; i++) {
                                                        const number = Math.floor(Math.random() * resultShowPre.length);
                                                        let exist = false;
                                                        for (var j = 0; j < quizArray.length; j++) {
                                                            if (number == quizArray[j]) {
                                                                exist = true;
                                                                break;
                                                            }

                                                        }
                                                        if (exist) {
                                                            i--;
                                                        }
                                                        else {
                                                            quizArray.push(number);
                                                        }
                                                    }

                                                    const resultShowPre1 = [{ question_id: resultShowPre[quizArray[0]].question_id, question: resultShowPre[quizArray[0]].question, level: resultShowPre[quizArray[0]].level, answers: resultShowPre[quizArray[0]].answers },
                                                    { question_id: resultShowPre[quizArray[1]].question_id, question: resultShowPre[quizArray[1]].question, level: resultShowPre[quizArray[1]].level, answers: resultShowPre[quizArray[1]].answers },
                                                    { question_id: resultShowPre[quizArray[2]].question_id, question: resultShowPre[quizArray[2]].question, level: resultShowPre[quizArray[2]].level, answers: resultShowPre[quizArray[2]].answers },
                                                    { question_id: resultShowPre[quizArray[3]].question_id, question: resultShowPre[quizArray[3]].question, level: resultShowPre[quizArray[3]].level, answers: resultShowPre[quizArray[3]].answers },
                                                    { question_id: resultShowPre[quizArray[4]].question_id, question: resultShowPre[quizArray[4]].question, level: resultShowPre[quizArray[4]].level, answers: resultShowPre[quizArray[4]].answers },];
                                                    res.send({ quiz: resultShowPre1, showQuiz: true })


                                                }
                                            })
                                        }
                                        else {
                                            if (resultModule.length > 0) {
                                                let resultModCategories=[];
                                                for (let i = 0; i < resultCategories.length; i++) {
                                                    let modules=0;
                                                    for (let j = 0; j < resultModule.length; j++) {
                                                        if(resultCategories[i].title==resultModule[j].title){
                                                            modules=resultModule[j].numM;
                                                            break;
                                                        }
                                                    }
                                                    resultModCategories.push({category_id:resultCategories[i].category_id,title:resultCategories[i].title,description:resultCategories[i].description,location:resultCategories[i].location,modules:modules})
                                                }
                                                res.send({ categories: resultModCategories, showQuiz: false })
                                            }
                                            else {
                                                res.send({ categories: resultCategories, showQuiz: false })
                                            }
                                        }
                                    }
                                }
                            });

                        }
                    });
                }
            })

        }
    });
})

router.post('/solveQuiz', verifyToken,(req, res) => {
    const user = jwt_decode(req.headers['authorization'])
    const question1 = req.body.question1;
    const question2 = req.body.question2;
    const question3 = req.body.question3;
    const question4 = req.body.question4;
    const question5 = req.body.question5;
    const answer1 = req.body.answer1;
    const answer2 = req.body.answer2;
    const answer3 = req.body.answer3;
    const answer4 = req.body.answer4;
    const answer5 = req.body.answer5;
   
    const sqlQuiz = 'SELECT * FROM quiz WHERE question_id=? || question_id=? || question_id=? || question_id=? || question_id=?;'
    const sqlInsertQuiz = 'INSERT INTO solvesQuiz(user_id,questions,answers,answersUser,score,level,created) VALUES(?,?,?,?,?,?,now())'
    if (!answer1 || !answer2 || !answer3 || !answer4 || !answer5) {
        res.send({ messageError: 'Por favor responda todas las preguntas para continuar' });
    }
    else {
        db.query(sqlQuiz, [question1, question2, question3, question4, question5], (err, result0) => {
            if (err) {
                res.send({ messageError: "Error en el servidor. Contacte al administrador" });
                console.log(err);
            }
            else {
                if (result0.length < 5) {
                    res.send({ messageError: "Una pregunta fue borrada o eliminada, recargue e intente de nuevo!" });

                }
                else {
                    let points = 0;
                    for (let i = 0; i < result0.length; i++) {
                        if (result0[i].question_id == question1) {
                            if (result0[i].correctAnswer == answer1) {
                                points++;
                            }
                        }
                        else if (result0[i].question_id == question2) {
                            if (result0[i].correctAnswer == answer2) {
                                points++;
                            }
                        }
                        else if (result0[i].question_id == question3) {
                            if (result0[i].correctAnswer == answer3) {
                                points++;
                            }
                        }
                        else if (result0[i].question_id == question4) {
                            if (result0[i].correctAnswer == answer4) {
                                points++;
                            }
                        }
                        else if (result0[i].question_id == question5) {
                            if (result0[i].correctAnswer == answer5) {
                                points++;
                            }
                        }
                    }
                    const questions = [result0[0].question, result0[1].question, result0[2].question, result0[3].question, result0[4].question]
                    const correctAnswers = [result0[0].correctAnswer, result0[1].correctAnswer, result0[2].correctAnswer, result0[3].correctAnswer, result0[4].correctAnswer]
                    const answersUser = [answer1, answer2, answer3, answer4, answer5];
                    const level = result0[0].level;
                    db.query(sqlInsertQuiz, [user.id, questions.toString(), correctAnswers.toString(), answersUser.toString(), points, level], (err, result0) => {
                        if (err) {
                            res.send({ messageError: "Error en el servidor, contacte al administrador" });
                            console.log(err);
                        }
                        else {
                            res.send({ messageScore: points });
                        }
                    })

                }

            }
        })

    }
})
router.post('/contentLearnHead', verifyToken,(req, res) => {
    const learn_id = req.body.learn_id;
    const sqlContent = "SELECT * FROM categories WHERE category_id=?";
    
    db.query(sqlContent, learn_id, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al obtener las categorias" });
        }
        else {
            res.send(result);
        }
    })

})

router.post('/questions', verifyToken,(req, res) => {
    const learn_id = req.body.learn_id;
    const sqlContent = "SELECT flags.flag_id,flags.question FROM learning INNER JOIN flags ON learning.learn_id=flags.learn_id WHERE learning.learn_id=?";
    db.query(sqlContent, learn_id, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al obtener las preguntas" });
        }
        else {
            if (result.length > 0) {
                res.send(result);
            }
            else {
                res.send({ messageError: "Error al obtener las preguntas" });
            }
        }
    })

})

router.post('/contentLearn', verifyToken,(req, res) => {
    //aparecer niveles segun resueltos
    const learn_id = req.body.learn_id;
    const user = jwt_decode(req.headers['authorization'])
    const sqlSolvesTotal = "SELECT learning.level, SUM(flags.score) as totalScore FROM learning INNER JOIN flags ON learning.learn_id=flags.learn_id WHERE learning.category_id=? GROUP BY learning.level";
    const sqlSolvesUser = "SELECT learning.level, SUM(flags.score) as totalScore FROM learning INNER JOIN flags ON learning.learn_id=flags.learn_id INNER JOIN solvesLearn ON solvesLearn.flag_id=flags.flag_id WHERE learning.category_id=? AND solvesLearn.USER_id=? GROUP BY learning.level";
    const sqlContentEasy = "SELECT * FROM learning WHERE category_id=? and level='Fácil' ";
    const sqlContentMedium = "SELECT * FROM learning WHERE category_id=? and (level='Fácil' or level='Intermedio')";
    const sqlContentHard = "SELECT * FROM learning WHERE category_id=?";

    db.query(sqlContentHard, learn_id, (err, result) => {
        if(err){
            console.log(err);
            throw err;
        }
        res.send(result)

    })
})
router.post('/checkFlag', verifyToken,(req, res) => {
    const flag_id = req.body.flag_id;
    const flag = req.body.flag;
    const user = jwt_decode(req.headers['authorization'])
    const sqlUser = "SELECT * FROM solvesLearn WHERE user_id=? and flag_id=?";
    const sqlSelectFlag = "SELECT * FROM flags WHERE flag_id=?";
    const dateNow = new Date();
    const sqlInsert = "INSERT INTO solvesLearn (flag_id, user_id, created) VALUES (?,?,?)";
    db.query(sqlUser, [user.id, flag_id], (err, result1) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrio un error al obtener la pregunta" });
            throw err;
        }
        else {
            if (result1.length > 0) {
                res.send({ messageError: "Ya has resuelto esta pregunta!" });
            }
            else {
                db.query(sqlSelectFlag, flag_id, (err, result) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Ocurrio un error al obtener la pregunta" });
                    }
                    else {
                        if (result.length > 0) {
                            if (result[0].flag == flag) {
                                db.query(sqlInsert, [flag_id, user.id, dateNow], (err, result) => {
                                    if (err) {
                                        console.log(err);
                                        res.send({ messageError: "Ocurrio un error al insertar el reto" });
                                    }
                                    else {
                                        res.send({ messageSuccess: "Reto resuelto" });
                                    }
                                })
                            } else {
                                res.send({ messageError: "Incorrecto" });
                            }
                        }
                        else {
                            res.send({ messageError: "No hay preguntas disponibles" });
                        }
                    }
                })
            }

        }
    });


})

router.post('/getLearnID',verifyToken, (req, res) => {
    const learn_id = req.body.learn_id;
    const sqlContent = "SELECT * FROM learning WHERE learn_id=?";
    db.query(sqlContent, learn_id, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al obtener las categorias" });
            throw err;
        }
        else {
            res.send(result);
        }
    })
})
router.get('/getLink',verifyToken, (req, res) => {
    const sqlContent = "SELECT form,showForm FROM settings WHERE setting_id=1"
    db.query(sqlContent, (err, result) => {
        if (err) {
            res.send({ messageError: "Error al obtener la informacion" });
            console.log(err);
        }
        else {
            res.send(result);
        }
    })

})
module.exports = router;
