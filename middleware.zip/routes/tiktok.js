const express = require('express');
const router = express.Router();
const jwt_decode = require('jwt-decode')
const bcrypt = require("bcrypt");
const { verifyToken } = require('../middleware/auth');
const db = require("../database");
const { exec } = require("child_process");
// OAuth 1.0a (User context)

router.get("/getHash", async (req, res) => {
    const hashtag = req.body.hashtag;
    exec("dir", (error, stdout, stderr) => {
        if (error) {
            console.log(`error: ${error.message}`);
            return;
        }
        if (stderr) {
            console.log(`stderr: ${stderr}`);
            return;
        }
        console.log(`stdout: ${stdout}`);
    });

})
router.get("/getMembers", verifyToken, (req, res) => {
    const user = jwt_decode(req.headers['authorization'])
    const user_id = user.id;
    const sqlSelectTeam = 'SELECT team_id from users WHERE user_id=?';
    const sqlSelectUsers = 'SELECT users.user_id,users.username from users WHERE users.team_id=?  ';
    const sqlSelectMembersSolves = 'SELECT users.user_id, users.username, SUM(challenges.value) as score FROM solves INNER JOIN users ON solves.user_id=users.user_id INNER JOIN challenges ON solves.challenge_id=challenges.challenge_id WHERE solves.team_id=? GROUP BY users.user_id ORDER BY score DESC';
    db.query(sqlSelectTeam, user_id, (err, result1) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result1.length > 0) {
                db.query(sqlSelectUsers, result1[0].team_id, (err, result2) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                        throw err;
                    }
                    else {
                        db.query(sqlSelectMembersSolves, result1[0].team_id, (err, result3) => {
                            if (err) {
                                console.log(err);
                                res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                throw err;
                            }
                            else {
                                var finalResult = [];
                                for (i in result2) {
                                    let inResult = false;
                                    let position = 0;
                                    for (j in result3) {
                                        if (result2[i].username == result3[j].username) {
                                            inResult = true;
                                            position = j;
                                        }
                                    }
                                    if (inResult) {
                                        finalResult.push({ id: result3[position].user_id, username: result3[position].username, score: result3[position].score });
                                    }
                                    else {
                                        finalResult.push({ id: result2[i].user_id, username: result2[i].username, score: 0 });
                                    }

                                }
                                res.send(finalResult);
                            }
                        })
                    }
                })
            } else {
                res.send({ messageError: "No perteneces a un equipo!" });
            }
        }
    });
})
router.post("/joinTeam", verifyToken, (req, res) => {
    const user = jwt_decode(req.headers['authorization'])
    const team = req.body.name;
    const password = req.body.password;
    const sqlJoin = "UPDATE users SET team_id= ? WHERE user_id= ?";
    const sqlSelect = "SELECT team_id, password FROM teams WHERE name = ?";
    const sqlSelectCaptain = "select captain_id from teams where name=?";
    const sqlUpdateCaptain = "UPDATE teams SET captain_id=? WHERE name=?";


    db.query(sqlSelect, [team], (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result.length > 0) {
                bcrypt.compare(password, result[0].password, (err, resul) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                        throw err;
                    }
                    else {
                        if (resul) {
                            db.query(sqlJoin, [result[0].team_id, user.id], (err, result2) => {
                                if (err) {
                                    console.log(err);
                                    res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                    throw err;
                                }
                                else {
                                    db.query(sqlSelectCaptain, [team], (err, result3) => {
                                        if (err) {
                                            console.log(err);
                                            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                            throw err;
                                        }
                                        else {
                                            if (result3.length > 0) {
                                                if (result3[0].captain_id != null) {
                                                    res.send({ messageSuccess: "Te has unido al equipo", team: true });
                                                } else {
                                                    db.query(sqlUpdateCaptain, [user.id, team], (err, result4) => {
                                                        if (err) {
                                                            console.log(err);
                                                            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                                            throw err;
                                                        }
                                                        else {
                                                            res.send({ messageSuccess: "Te has unido al equipo", team: true });
                                                        }
                                                    })
                                                }
                                            }
                                            else {
                                                res.send({ messageSuccess: "Te has unido al equipo", team: true });
                                            }

                                        }

                                    })
                                }
                            })
                        }
                        else {
                            res.send({ messageError: "Contraseña incorrecta" });
                        }

                    }
                })


            }
            else {
                res.send({ messageError: "El equipo no existe!" });
            }
        }
    });


}
);
router.post('/createTeam', verifyToken, (req, res) => {
    const user = jwt_decode(req.headers['authorization'])
    const { name, password } = req.body;
    const today = new Date();
    const date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    const time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    const dateTime = date + ' ' + time;
    const sqlSelectTeamExist = 'SELECT * FROM teams WHERE name=?';
    const sqlSelectUserInTeam = 'SELECT team_id FROM users WHERE user_id=?';
    const sqlInsertTeam = "INSERT INTO teams (captain_id,name,password,created) VALUES (?,?,?,?)";
    const sqlSelectCaptain = 'SELECT team_id FROM teams WHERE captain_id=?';
    const sqlUpdateTeamInUser = 'UPDATE users SET team_id= ? WHERE user_id=?';
    if (name == '') {
        res.send({ messageError: "El nombre del equipo no puede estar vacío!" });
    }
    else if (password == '') {
        res.send({ messageError: "La contraseña no puede estar vacía!" });
    }
    else {
        db.query(sqlSelectTeamExist, name, (err, resultSel) => {
            if (err) {
                console.log(err);
                res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                throw err;
            }
            else {
                if (resultSel.length > 0) {
                    res.send({ messageError: "El equipo ya existe!" });
                } else {
                    db.query(sqlSelectUserInTeam, user.id, (err, resUser) => {
                        if (err) {
                            console.log(err);
                            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                            throw err;
                        }
                        else {
                            if (resUser.length > 0) {
                                if (resUser[0].team_id != null) {
                                    res.send({ messageError: "Ya perteneces a un equipo!" });
                                } else {
                                    bcrypt.hash(password, 10, (err, hash) => {
                                        if (err) {
                                            console.log(err);
                                            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                            throw err;
                                        }
                                        else {
                                            db.query(sqlInsertTeam, [user.id, name, hash, dateTime], (err, resultOne) => {
                                                if (err) {
                                                    console.log(err);
                                                    res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                                    throw err;
                                                }
                                                else {
                                                    db.query(sqlSelectCaptain, [user.id], (err, resultTwo) => {
                                                        db.query(sqlUpdateTeamInUser, [resultTwo[0].team_id, user.id], (err, result) => {
                                                            res.send({ messageSuccess: "Equipo creado!" });
                                                        });
                                                    });
                                                }
                                            });

                                        }
                                    })

                                }
                            } else {
                                res.send({ message: "Error con el usuario!" });
                            }
                        }
                    });
                }
            }
        });

    }

});
router.get("/getCaptain", verifyToken, (req, res) => {
    const user = jwt_decode(req.headers['authorization'])
    const sqlSelect = "SELECT captain_id FROM teams INNER JOIN users ON teams.team_id=users.team_id WHERE users.user_id=?";
    db.query(sqlSelect, user.id, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result[0].captain_id == user.id) {
                res.send({ captain: result[0].captain_id, isCaptain: true, myID: user.id });
            }
            else {
                res.send({ captain: result[0].captain_id, isCaptain: false, myID: user.id });
            }
        }
    })
});
router.put("/updateCaptain", verifyToken, (req, res) => {
    const changeCaptain = req.body.newCaptain;
    const sqlSelectUser = "SELECT user_id, team_id FROM users WHERE username=?";
    const sqlUpdateTeam = "UPDATE teams SET captain_id= ? WHERE team_id= ?";
    db.query(sqlSelectUser, changeCaptain, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result.length > 0) {
                db.query(sqlUpdateTeam, [result[0].user_id, result[0].team_id], (err, result2) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                        throw err;
                    }
                    else {
                        res.send({ messageSuccess: "Capitan Actualizado" });
                    }

                });
            }
            else {
                res.send({ messageError: "El usuario no existe!" });
            }
        }

    });
});
router.put("/leaveTeam", verifyToken, (req, res) => {
    const user = jwt_decode(req.headers['authorization'])
    const sqlUpdate = "UPDATE users SET team_id= null WHERE user_id= ?";
    const sqlDeleteSolves = "DELETE FROM solves WHERE user_id= ?";
    const sqlSearch = "SELECT * FROM users WHERE team_id= (SELECT team_id FROM users WHERE user_id=?)";
    const deleteTeam = "DELETE FROM teams WHERE team_id=?";
    const sqlCaptain = "SELECT captain_id FROM teams WHERE team_id = ?"
    const sqlOtherCaptain = "SELECT user_id FROM users WHERE team_id = ?"
    const updateCaptain = "UPDATE teams SET captain_id=? WHERE team_id=?"
    db.query(sqlSearch, user.id, (err, result1) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else if (result1.length == 0 || result1[0].team_id == null) {
            res.send({ messageError: "No perteneces a un equipo!" });
        }
        else {
            db.query(sqlUpdate, [user.id], (err, result2) => {
                if (err) {
                    console.log(err);
                    res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                    throw err;
                }
                else {
                    db.query(sqlDeleteSolves, [user.id], (err, result3) => {
                        if (err) {
                            console.log(err);
                            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                            throw err;
                        }
                        else {

                            if (result1.length > 1) {
                                db.query(sqlCaptain, result1[0].team_id, (err, result4) => {
                                    if (result4[0].captain_id == user.id) {
                                        db.query(sqlOtherCaptain, result1[0].team_id, (err, result5) => {
                                            if (err) {
                                                console.log(err);
                                                res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                                throw err;
                                            }
                                            else {
                                                db.query(updateCaptain, [result5[0].user_id, result1[0].team_id], (err, result6) => {
                                                    if (err) {
                                                        console.log(err);
                                                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                                        throw err;
                                                    }
                                                    else {
                                                        res.send({ messageSuccess: "Te haz salido del equipo" });
                                                    }
                                                })
                                            }

                                        })
                                    }
                                    else {
                                        res.send({ messageSuccess: "Te haz salido del equipo" });
                                    }

                                })
                            }
                            else {
                                db.query(deleteTeam, result1[0].team_id, (err, result4) => {
                                    if (err) {
                                        console.log(err);
                                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                        throw err;
                                    }
                                    else {
                                        res.send({ messageSuccess: "Te haz salido del equipo!" });
                                    }
                                })
                            }
                        }

                    })
                }

            })
        }

    })
});

module.exports = router;