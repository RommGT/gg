const express = require('express');
const router = express.Router();
const jwt_decode = require('jwt-decode')
const db = require("../database");
const { format } = require('date-fns-tz')
const { verifyToken, isAdmin } = require('../middleware/auth');
router.post('/postWriteup', verifyToken, (req, res) => {
    const user = jwt_decode(req.headers['authorization'])
    const { title, category, link } = req.body;
    const sqlInsert = "INSERT INTO writeups (user_id,title,category_id,link,created) VALUES (?,?,?,?,?)";
    const today = new Date();
    const pattern = 'yyyy-MM-d HH:mm:ss'
    const date = format(today, pattern, { timeZone: 'America/Guayaquil' });
    db.query(sqlInsert, [user.id, title, category, link, date], (err, result) => {

        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            res.send({ messageSuccess: "Writeup subido!" });
        }
    })

})

router.get("/getWriteup", verifyToken, (req, res) => {
    const user = jwt_decode(req.headers['authorization'])
    const sqlSelect = 'SELECT users.user_id,users.username,writeups.writeup_id, writeups.title as writeup, categories.title as category, writeups.link, writeups.created  FROM writeups INNER JOIN users ON writeups.user_id=users.user_id INNER JOIN categories ON writeups.category_id=categories.category_id';
    db.query(sqlSelect, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            const writeupList = [];
            if (result.length > 0) {
                for (i in result) {
                    writeupList.push({
                        user_id: result[i].user_id,
                        username: result[i].username,
                        writeup_id: result[i].writeup_id,
                        writeup: result[i].writeup,
                        category: result[i].category,
                        link: result[i].link,
                        created: result[i].created,
                        owner: user.id == result[i].user_id ? true : false
                    });
                }
                res.send(writeupList);
            }
            else {
                res.send([{ user_id: 1, username: "admin", writeup_id: 1, writeup: "No hay writeups", category: "No hay categorias", link: "No hay links", created: "No hay fechas", owner: true }]);
            }
        }
    });
})

router.post('/getWriteupInfo', verifyToken, (req, res) => {
    const { writeup_id } = req.body;
    const { user_id } = req.body;
    const sqlSelect = 'SELECT users.username,writeups.writeup_id, writeups.title as writeup, writeups.category_id as category, writeups.link, writeups.created  FROM writeups INNER JOIN users ON writeups.user_id=users.user_id  WHERE writeups.writeup_id=? AND writeups.user_id=?';
    db.query(sqlSelect, [writeup_id, user_id], (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result.length > 0) {
                res.send(result[0]);
            }
            else {
                res.send({ messageError: "No puedes editar el writeup!" });
            }
        }
    })
})

router.post('/getWriteupAdminInfo', verifyToken, isAdmin, (req, res) => {
    const { writeup_id } = req.body;
    const sqlSelect = 'SELECT writeups.writeup_id, writeups.title as writeup, writeups.category_id as category, writeups.link, writeups.created  FROM writeups WHERE writeups.writeup_id=?';
    db.query(sqlSelect, [writeup_id], (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result.length > 0) {
                res.send(result[0]);
            }
            else {
                res.send({ messageError: "No puedes editar el writeup!" });
            }
        }
    })
})
router.put("/updateWriteup", verifyToken, (req, res) => {
    const user = jwt_decode(req.headers['authorization'])
    const { writeup_id, title, category, link } = req.body;
    const sqlSelect = 'SELECT * FROM writeups WHERE writeup_id=? and user_id=?';
    const sqlUpdate = "UPDATE writeups SET title=?, category_id=?, link=?, created=? WHERE writeup_id=? and user_id=?";
    const today = new Date();
    const pattern = 'yyyy-MM-d HH:mm:ss'
    const date = format(today, pattern, { timeZone: 'America/Guayaquil' });
    db.query(sqlSelect, [writeup_id, user.id], (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result.length > 0) {
                db.query(sqlUpdate, [title ? title : result[0].title, category ? category : result[0].category_id, link ? link : result[0].link, date, writeup_id, user.id], (err, result2) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                        throw err;
                    }
                    else {
                        res.send({ messageSuccess: "Writeup actualizado!" });
                    }
                })
            }
            else {
                res.send({ messageError: "No es tu writeup!" });
            }
        }
    })
})
router.put("/updateAdminWriteup", verifyToken, isAdmin, (req, res) => {
    const { writeup_id, title, category, link } = req.body;
    const sqlUpdate = "UPDATE writeups SET title=?, category_id=?, link=? WHERE writeup_id=?";
    db.query(sqlUpdate, [title ? title : result[0].title, category ? category : result[0].category_id, link ? link : result[0].link, writeup_id], (err, result2) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            res.send({ messageSuccess: "Writeup actualizado!" });
        }
    })



})
router.delete("/deleteWriteup/:id", verifyToken, (req, res) => {

    const user = jwt_decode(req.headers['authorization'])
    const writeup_id = req.params.id;
    const sqlDelete = "DELETE FROM writeups WHERE writeup_id=? and user_id=?";
    db.query(sqlDelete, [writeup_id, user.id], (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result.affectedRows > 0) {
                res.send({ messageSuccess: "Writeup eliminado!" });
            }
            else {
                res.send({ messageError: "No se pudo eliminar el writeup!" });
            }
        }
    })
})
router.delete("/deleteAdminWriteup/:id", verifyToken, isAdmin, (req, res) => {
    const writeup_id = req.params.id;
    const sqlDelete = "DELETE FROM writeups WHERE writeup_id=?";
    db.query(sqlDelete, [writeup_id], (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result.affectedRows > 0) {
                res.send({ messageSuccess: "Writeup eliminado!" });
            }
            else {
                res.send({ messageError: "No se pudo eliminar el writeup!" });
            }
        }
    })
})
module.exports = router;