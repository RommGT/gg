const express = require('express');
const router = express.Router();
const { verifyToken } = require('../middleware/auth');
const db = require("../database");
const { format } = require('date-fns-tz')

router.get('/getTimers', (req, res) => {
    const sqlDate = "SELECT startDate, endDate, showTime from settings"
    db.query(sqlDate, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al obtener la fecha" });
        }
        else {
            const dateN = new Date();
            const dateS = new Date(result[0].startDate);
            const dateE = new Date(result[0].endDate);
            const showTime = result[0].showTime;
            const pattern = 'yyyy-MM-d HH:mm:ss'
            const dateN1 = format(dateN, pattern, { timeZone: 'America/Guayaquil' });
            const dateS1 = format(dateS, pattern, { timeZone: 'Americas/Guayaquil' });
            const dateE1 = format(dateE, pattern, { timeZone: 'Americas/Guayaquil' });
            const dateNow = new Date(dateN1);
            const dateStart = new Date(dateS1);
            const dateEnd = new Date(dateE1);
            if (dateNow > dateStart && dateNow < dateEnd) {
                const totalSeconds1 = (dateEnd.getTime() - dateNow.getTime()) / 1000;
                res.send({ running: true, totalSeconds: totalSeconds1 });
            }
            else {
                if (dateNow > dateEnd) {
                    res.send({ finish: true, totalSeconds: 0 });
                }
                else if (dateNow < dateStart) {
                    const totalSeconds2 = (dateStart.getTime() - dateNow.getTime()) / 1000;
                    res.send({ notStart: true, totalSeconds: totalSeconds2, showTime: showTime });
                }
                else {
                    res.send({ notEvent: true, totalSeconds: 0 });
                }
            }
        }
    })
})
router.get('/getTimersUser', verifyToken, (req, res) => {
    const sqlDate = "SELECT startDate, endDate from settings"
    db.query(sqlDate, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al obtener la fecha" });
        }
        else {
            const dateN = new Date();
            const dateS = new Date(result[0].startDate);
            const dateE = new Date(result[0].endDate);
            const pattern = 'yyyy-MM-d HH:mm:ss'
            const dateN1 = format(dateN, pattern, { timeZone: 'America/Guayaquil' });
            const dateS1 = format(dateS, pattern, { timeZone: 'Americas/Guayaquil' });
            const dateE1 = format(dateE, pattern, { timeZone: 'Americas/Guayaquil' });
            const dateNow = new Date(dateN1);
            const dateStart = new Date(dateS1);
            const dateEnd = new Date(dateE1);
            if (dateNow > dateStart && dateNow < dateEnd) {
                const totalSeconds1 = (dateEnd.getTime() - dateNow.getTime()) / 1000;
                res.send({ running: true, totalSeconds: totalSeconds1 });
            }
            else {
                if (dateNow > dateEnd) {
                    res.send({ finish: true, totalSeconds: 0 });
                }
                else if (dateNow < dateStart) {
                    const totalSeconds2 = (dateStart.getTime() - dateNow.getTime()) / 1000;
                    res.send({ notStart: true, totalSeconds: totalSeconds2 });
                }
                else {
                    res.send({ notEvent: true, totalSeconds: 0 });
                }
            }
        }
    })
})
router.get('/getHomeInfo', (req, res) => {
    const sqlInfo = "SELECT title,content FROM settings"
    db.query(sqlInfo, (err, result) => {
        if (err) {
            res.send({ message: "Error al obtener la información" })
            console.log(err)
        }
        else {
            res.send(result[0])

        }
    })

})
router.get('/getCompetitionInfo', verifyToken, (req, res) => {
    const sqlInfo = "SELECT information from settings";
   
    db.query(sqlInfo, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al obtener la informacion" });
        }
        else {
            if (result.length > 0) {
                if(result[0].information != null){
                res.send([{ information: result[0].information }]);
                }
                else{
                    res.send({ information: "" });
                }
            }
            else{
                res.send({ information: "" });
            }
        }
    })
})
module.exports = router;