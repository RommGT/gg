
const express = require('express');
const router = express.Router();
const jwt_decode = require('jwt-decode')
const { format } = require('date-fns-tz')
const db = require("../database");
const { verifyToken } = require('../middleware/auth');

router.get("/getTop10",verifyToken, (req, res) => {
    const sqlSelect = "SELECT  teams.team_id,teams.name as name,SUM(challenges.value) as score, MAX(solves.created) as fecha FROM solves INNER JOIN challenges ON challenges.challenge_id = solves.challenge_id INNER JOIN teams ON teams.team_id = solves.team_id GROUP BY solves.team_id ORDER BY score DESC, fecha ASC LIMIT 10"
    const sqlHints = "SELECT team_id,SUM(cost) as cost from openHints INNER JOIN hints WHERE openHints.hint_id=hints.hint_id GROUP BY team_id;"
    db.query(sqlSelect, (err, response) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al obtener los datos" });
            throw err;
        }
        else {
            if (response.length > 0) {
                db.query(sqlHints, (err, result2) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Error al obtener los datos" });
                        throw err;
                    }
                    else {
                        if (result2.length > 0) {
                            let scoreboard = [];
                            for (let i = 0; i < response.length; i++) {
                                let cost = 0;
                                for (let k = 0; k < result2.length; k++) {
                                    if (response[i].team_id == result2[k].team_id) {
                                        cost = result2[k].cost;
                                        break;
                                    }
                                }
                                scoreboard.push({ team_id: response[i].team_id, name: response[i].name, score: response[i].score - cost });
                            }
                            scoreboard = scoreboard.sort(function (a, b) {
                                return b.score - a.score;
                            });


                            const users = [];
                            const scores = [];
                            const scoreboardFinal = [];
                            for (let m = 0; m < scoreboard.length; m++) {
                                users.push(scoreboard[m].name);
                                scores.push(scoreboard[m].score);
                            }
                            scoreboardFinal.push(users, scores);
                            res.send(scoreboardFinal);

                        }
                        else {
                            const users = [];
                            const scores = [];
                            const scoreboard = [];
                            for (let i = 0; i < response.length; i++) {
                                users.push(response[i].name);
                                scores.push(response[i].score);
                            }
                            scoreboard.push(users, scores);
                            res.send(scoreboard);
                        }

                    }
                })

            }
            else {
                res.send({ messageError: "No hay datos disponibles" });
            }
        }
    });
});

router.get("/getScores",verifyToken, (req, res) => {
    const sqlSelect = "SELECT  teams.team_id,teams.name,SUM(challenges.value) as score, MAX(solves.created)as fecha FROM solves INNER JOIN challenges ON challenges.challenge_id = solves.challenge_id INNER JOIN teams ON teams.team_id = solves.team_id GROUP BY solves.team_id ORDER BY score DESC, fecha ASC"
    const sqlHints = "SELECT team_id,SUM(cost) as cost from openHints INNER JOIN hints WHERE openHints.hint_id=hints.hint_id GROUP BY team_id;"
    db.query(sqlHints, (err, resultHint) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al obtener los datos" });
            throw err;
        }
        else {
            db.query("SELECT team_id,name FROM teams", (err, result1) => {
                if (err) {
                    console.log(err);
                    res.send({ messageError: "Error al obtener los datos" });
                    throw err;
                }
                else {
                    db.query(sqlSelect, (err, result2) => {
                        if (err) {
                            console.log(err);
                            res.send({ messageError: "Error al obtener los datos" });
                            throw err;
                        }
                        else {
                            if (result1.length > 0) {
                                let scoreboard = [];
                                let countPlace = 0;
                                if (result2.length > 0) {
                                    if (resultHint.length > 0) {
                                        for (let i = 0; i < result2.length; i++) {
                                            let cost = 0;
                                            for (let k = 0; k < resultHint.length; k++) {
                                                if (result2[i].team_id == resultHint[k].team_id) {
                                                    cost = resultHint[k].cost;
                                                    break;
                                                }
                                            }
                                            scoreboard.push({ team_id: result2[i].team_id, name: result2[i].name, score: result2[i].score - cost });
                                        }
                                        scoreboard = scoreboard.sort(function (a, b) {
                                            return b.score - a.score;
                                        });
                                        let scoreboardTemp = [];
                                        for (let h = 0; h < scoreboard.length; h++) {
                                            scoreboardTemp.push({ team_id: scoreboard[h].team_id, place: h + 1, name: scoreboard[h].name, score: scoreboard[h].score });
                                        }
                                        scoreboard = scoreboardTemp;
                                    } else {
                                        for (let i = 0; i < result2.length; i++) {
                                            scoreboard.push({ team_id: result2[i].team_id, place: i + 1, name: result2[i].name, score: result2[i].score });
                                        }
                                    }

                                    countPlace = scoreboard[scoreboard.length - 1].place;
                                }
                                for (let j = 0; j < result1.length; j++) {
                                    let found = false;
                                    for (let h = 0; h < scoreboard.length; h++) {
                                        if (scoreboard[h].name == result1[j].name) {
                                            found = true;
                                        }
                                    }
                                    if (!found) {
                                        countPlace++;
                                        scoreboard.push({ team_id: result1[j].team_id, place: countPlace, name: result1[j].name, score: 0 });
                                    }
                                }

                                res.send(scoreboard);
                            }
                            else {
                                res.send([{ team_id: 0, place: 0, name: "No hay equipos", score: 0 }]);
                            }

                        }

                    });
                }
            });

        }
    })


});

router.post("/getSolvesTeam", verifyToken,(req, res) => {
    const team_id = req.body.team_id;
    const sqlSelect = "SELECT  challenges.name as name, challenges.value as value, solves.created as fecha FROM solves INNER JOIN challenges ON challenges.challenge_id = solves.challenge_id WHERE solves.team_id = ? ORDER BY fecha DESC"
    const sqlSelectHint = "SELECT cost,challenges.name,openHints.created from openHints INNER JOIN hints ON openHints.hint_id=hints.hint_id INNER JOIN challenges ON hints.challenge_id=challenges.challenge_id WHERE openHints.team_id = ?"
    db.query(sqlSelect, team_id, (err, response) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al obtener los datos" });
            throw err;
        }
        else {

            if (response.length > 0) {
                db.query(sqlSelectHint, team_id, (err, resHint) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Error al obtener los datos" });
                        throw err;
                    }
                    else {
                        if (resHint.length > 0) {
                            const solves = [];
                            for (let i = 0; i < response.length; i++) {
                                const today = new Date(response[i].fecha );
                                const pattern = 'yyyy-MM-d HH:mm:ss'
                                const date = format(today, pattern, { timeZone: 'America/Guayaquil' });
                                solves.push({ name: response[i].name, value: response[i].value, fecha: date});
                            }
                            for (let j = 0; j < resHint.length; j++) {
                                const today = new Date(resHint[j].created);
                                const pattern = 'yyyy-MM-d HH:mm:ss'
                                const date = format(today, pattern, { timeZone: 'America/Guayaquil' });
                                solves.push({ name: 'Pista:' + resHint[j].name, value: -resHint[j].cost, fecha: date});
                            }
                            res.send(solves);

                        }
                        else {
                            const solves = [];
                            for (let i = 0; i < response.length; i++) {

                                const today = new Date(response[i].fecha );
                                const pattern = 'yyyy-MM-d HH:mm:ss'
                                const date = format(today, pattern, { timeZone: 'America/Guayaquil' });
                                solves.push({ name: response[i].name, value: response[i].value, fecha: date});
                            }
                            res.send(solves);

                        }

                    }
                })

            }
            else {
                res.send([{ name: 'El equipo no ha resuelto ningún reto', value: 0, fecha: 0 }]);
            }
        }
    });

});
module.exports = router;
