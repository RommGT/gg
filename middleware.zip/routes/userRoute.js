const express = require('express');
const router = express.Router();
const jwt = require("jsonwebtoken");
const jwt_decode = require('jwt-decode')
const bcrypt = require("bcrypt");
const db = require("../database");
const { verifyToken } = require('../middleware/auth');
require('dotenv').config();
//users
router.post("/register", (req, res) => {
    const name = req.body.name;
    const username = req.body.username;
    const email = req.body.email;
    const password = req.body.password;
    const code = req.body.code;
    const sqlCode = "SELECT code FROM settings";
    const type = 'user';
    const today = new Date();
    const date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    const time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    const dateTime = date + ' ' + time;
    db.query(sqlCode, (err, result0) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result0[0].code == code) {
                bcrypt.hash(password, 10, (err, hash) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                        throw err;
                    }
                    else {
                        db.query("SELECT * FROM users WHERE username = ?", [username], (err, result) => {
                            if (err) {
                                console.log(err);
                                res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                throw err;
                            }
                            else {
                                if (result.length > 0) {
                                    if (result[0].username == username) {
                                        
                                        res.send({ messageError: "El usuario ya existe!" });
                                    }
                                }
                                else {
                                    db.query(
                                        "INSERT INTO users (name, username, email,type, password, created) VALUES (?,?,?,?,?,?)",
                                        [name, username, email, type, hash, dateTime],
                                        (err, result) => {
                                            if (err) {
                                                console.log(err);
                                                res.send({ messageError: "Ocurrió un error! Intente más tarde" })
                                                throw err;
                                            } else { res.send({ messageSuccess: "Usuario Creado Exitosamente!" }); }
                                        });
                                }
                            }
                        });
                    }
                });

            }
            else{
                res.send({ messageError: "Código incorrecto!" });
            }
        }
    });
});
router.get("/getCode",  (req, res) => {
    sqlSelect="SELECT code FROM settings";
    db.query(sqlSelect, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            res.send(result[0].code)
        }
    });
});
router.get("/changeCode",  (req, res) => {
    sqlUpdateCode="UPDATE settings SET code=?";
    const newCode= Math.floor(10000000 + Math.random() * 90000000);
    db.query(sqlUpdateCode,[newCode.toString()]);
});
router.get("/profile", verifyToken, (req, res) => {
    const user = jwt_decode(req.headers['authorization'])
    const user_id = user.id;
    const sqlSelect = 'SELECT name,username,email,institution,role FROM users WHERE user_id=?';
    db.query(sqlSelect, user_id, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            res.send(result)
        }
    });
});

router.put("/profileUpdate", verifyToken, (req, res) => {
    const username = req.body.username;
    const name = req.body.name;
    const email = req.body.email;
    const institution = req.body.institution;
    const role = req.body.role;
    const sqlUpdateName = 'UPDATE users SET name= ?, email= ?, institution= ?, role= ? WHERE username=?';
    db.query(sqlUpdateName, [name, email, institution, role, username], (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error, intentalo más tarde!" });
            throw err;
        }
        else {
            res.send({ messageSuccess: "Usuario actualizado correctamente!" });
        }
    });



})
router.put("/passwordUpdate", verifyToken, (req, res) => {
    const username = jwt_decode(req.headers['authorization']).username;
    const oldPassword = req.body.oldPassword;
    const newPassword = req.body.newPassword;
    const sqlSelectPassword = 'SELECT password FROM users WHERE username=?';
    const sqlUpdatePassword = 'UPDATE users SET password= ? WHERE username=?';
    db.query(sqlSelectPassword, [username], (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            bcrypt.compare(oldPassword, result[0].password, (err, result) => {
                if (err) {
                    console.log(err);
                    res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                    throw err;
                }
                else {

                    if (result) {

                        bcrypt.hash(newPassword, 10, (err, hash) => {
                            if (err) {
                                console.log(err);
                                res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                throw err;
                            }
                            else {
                                db.query(sqlUpdatePassword, [hash, username], (err, result) => {
                                    if (err) {
                                        console.log(err);
                                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                        throw err;
                                    }
                                    else {
                                        res.send({ messageSuccess: "Contraseña actualizada correctamente!" });
                                    }
                                });
                            }
                        });
                    }
                    else {
                        res.send({ messageError: "La contraseña actual no es correcta." });
                    }
                }
            });
        }
    });
});
router.delete("/userDelete/:user", (req, res) => {
    const username = req.params.user;
    const user = jwt_decode(req.headers['authorization']).username;
        if (username == 'adminCTF') {
            res.send({ messageError: "No puedes eliminar este usuario!" });
        } else {
    
            const sqlDeleteSolves= "DELETE FROM solves WHERE user_id=?;";
            const sqlDeleteSolvesLearn="DELETE FROM solvesLearn WHERE user_id=?;";
            const sqlDeleteWriteups="DELETE FROM writeups WHERE user_id=?;"
            const sqlHint= "DELETE FROM openHints WHERE user_id=?;"
            const sqlDelete = "DELETE FROM users WHERE username=?";
            db.query(sqlDeleteSolves, [user.id], (err, result) => {
                if (err) {
                    console.log(err)
                    res.send({ messageError: "Ocurrió un error, intentalo más tarde o contacta al administrador!" })
                    throw err;
                }
                else { 
                    db.query(sqlDeleteSolvesLearn, [user.id], (err, result) => {
                        if (err) {
                            console.log(err)
                            res.send({ messageError: "Ocurrió un error, intentalo más tarde o contacta al administrador!" })
                            throw err;
                        }
                        else { 
                            db.query(sqlDeleteWriteups, [user.id], (err, result) => {
                                if (err) {
                                    console.log(err)
                                    res.send({ messageError: "Ocurrió un error, intentalo más tarde o contacta al administrador!" })
                                    throw err;
                                }
                                else { 
                                    db.query(sqlHint, [user.id], (err, result) => {
                                        if (err) {
                                            console.log(err)
                                            res.send({ messageError: "Ocurrió un error, intentalo más tarde o contacta al administrador!" })
                                            throw err;
                                        }
                                        else { 
                                            db.query(sqlDelete, [username], (err, result) => {
                                                if (err) {
                                                    console.log(err)
                                                    res.send({ messageError: "Ocurrió un error, intentalo más tarde o contacta al administrador!" })
                                                    throw err;
                                                }
                                                else { res.send({ messageSuccess: "Usuario eliminado correctamente!" }) };
                                            }) 
                                        };
                                    })  
                                };
                            })  
                        };
                    }) 
                };
            })
           
        }
   
});

router.get("/getScoreLearn", verifyToken, (req, res) => {
    const user = jwt_decode(req.headers['authorization'])
    const user_id = user.id;
    const sqlSelect = 'SELECT SUM(score) as totalScore FROM flags';
    const sqlSelectSolves = "SELECT users.username, SUM(flags.score) AS score FROM solvesLearn INNER JOIN flags ON solvesLearn.flag_id = flags.flag_id INNER JOIN users ON solvesLearn.user_id = users.user_id GROUP BY users.username ORDER BY score DESC";
    db.query(sqlSelect, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result.length > 0) {
                db.query(sqlSelectSolves, (err, result2) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                        throw err;
                    }
                    else {
                        if (result2.length > 0) {
                            let list = [];
                            for (let i = 0; i < result2.length; i++) {
                                list.push({
                                    place: i + 1,
                                    username: result2[i].username,
                                    rank: result2[i].score > (result[0].totalScore * 0.25) ? result2[i].score > (result[0].totalScore * 0.45) ? result2[i].score > (result[0].totalScore * 0.60) ? result2[i].score > (result[0].totalScore * 0.75) ? result2[i].score > (result[0].totalScore * 0.90) ? 'Guru' : 'Elite Hacker' : 'Pro Hacker' : 'Hacker' : 'Script Kiddie' : 'Principiante',
                                    score: result2[i].score,

                                });
                            }
                            res.send(list)
                        } else {
                            res.send([{ place: 0, username: "Ningún flag ha sido resuelto", rank: "Principiante", score: 0 }])
                        }
                    }
                });

            }
            else {
                res.send([{ place: 0, username: "Ningún flag ha sido resuelto", rank: "Principiante", score: 0 }])

            }
        }
    });
});
router.get("/getUserRank", verifyToken, (req, res) => {
    const user = jwt_decode(req.headers['authorization'])
    const user_id = user.id;
    const sqlSelect = 'SELECT SUM(score) as totalScore FROM flags';
    const sqlSelectSolves = "SELECT users.username, SUM(flags.score) AS score FROM solvesLearn INNER JOIN flags ON solvesLearn.flag_id = flags.flag_id INNER JOIN users ON solvesLearn.user_id = users.user_id WHERE users.user_id=?";
    db.query(sqlSelect, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result.length > 0) {
                db.query(sqlSelectSolves, user_id, (err, result2) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                        throw err;
                    }
                    else {
                        if (result2.length > 0) {
                            res.send({ rank: result2[0].score > (result[0].totalScore * 0.25) ? result2[0].score > (result[0].totalScore * 0.45) ? result2[0].score > (result[0].totalScore * 0.60) ? result2[0].score > (result[0].totalScore * 0.75) ? result2[0].score > (result[0].totalScore * 0.90) ? 'Guru' : 'Elite Hacker' : 'Pro Hacker' : 'Hacker' : 'Script Kiddie' : 'Principiante', score: result2[0].score })
                        }
                        else {
                            res.send({ rank: 'Principiante', score: 0 })
                        }
                    }
                });

            }
            else {
                res.send({ rank: 'Principiante', score: 0 })

            }
        }
    });
});
router.get("/isLogged", (req, res) => {
    const token = req.headers['authorization'];
    if (token) {
        jwt.verify(token, process.env.SECRET_JWT, (err, decoded) => {
            if (err) {
                console.log(err);
                res.send({ logged: false });
                throw err;
            }
            else {
                res.send({ logged: true });
            }
        });
    } else {
        res.send({ logged: false });
    }
});

router.get("/isAdmin", (req, res) => {
    const token = req.headers['authorization'];
    if (token) {
        jwt.verify(token, process.env.SECRET_JWT, (err, decoded) => {
            if (err) {
                console.log(err);
                res.send({ isAdmin: false });
                throw err;
            }
            else {
                if (decoded.type == 'adminCTF21_UDLA!*') {
                    res.send({ isAdmin: true });
                } else {
                    res.send({ isAdmin: false });
                }
            }
        });
    } else {
        res.send({ isAdmin: false });
    }
});
module.exports = router;