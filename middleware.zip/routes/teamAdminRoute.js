const express = require('express');
const router = express.Router();
const bcrypt = require("bcrypt");
const db = require("../database");
const { verifyToken, isAdmin } = require('../middleware/auth');
const jwt_decode = require('jwt-decode')
router.post('/createTeam', verifyToken, isAdmin, (req, res) => {
    const { name, password, } = req.body;
    const today = new Date();
    const date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    const time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    const dateTime = date + ' ' + time;
    const sqlSelectTeamExist = 'SELECT * FROM teams WHERE name=?';
    const sqlInsertTeam = "INSERT INTO teams (name,password,created) VALUES (?,?,?)";
    db.query(sqlSelectTeamExist, name, (err, resultSel) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        } else {
            if (name == '') {
                res.send({ messageError: "El nombre del equipo no puede estar vacío!" });
            }
            else if (password == '') {
                res.send({ messageError: "La contraseña no puede estar vacía!" });
            }
            else {
                if (resultSel.length > 0) {
                    res.send({ messageError: "El nombre de equipo ya existe!" });
                } else {
                    bcrypt.hash(password, 10, (err, hash) => {
                        if (err) {
                            console.log(err);
                            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                            throw err;
                        }
                        else {
                            db.query(sqlInsertTeam, [name, hash, dateTime], (err, resultOne) => {
                                if (err) {
                                    console.log(err);
                                    res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                    throw err;
                                } else {
                                    res.send({ messageSuccess: "Equipo creado!" });
                                }
                            });

                        }
                    });

                }
            }
        }

    });
});

router.delete("/deleteAllTeam/:id", verifyToken, isAdmin, (req, res) => {
    const id = req.params.id;
    const updateTeamNull = "UPDATE users SET team_id=NULL WHERE team_id=?";
    const sqlDelete = "DELETE FROM teams WHERE team_id=?"
    db.query(updateTeamNull, id, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        } else {
            db.query(sqlDelete, id, (err, result) => {
                if (err) {
                    console.log(err);
                    res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                    throw err;
                }
                else {
                    res.send({ messageSuccess: "Equipo Eliminado" });
                }
            })
        }
    })
})





router.put("/deleteTeamUser", verifyToken, isAdmin, (req, res) => {
    const id = req.body.id;
    const sqlSearch = "SELECT (SELECT team_id from users WHERE user_id=?) AS team_id FROM users WHERE users.team_id=team_id"
    const sqlUpdate = "UPDATE users SET team_id= ? WHERE user_id= ?";
    const sqlDeleteSolves = "DELETE FROM solves WHERE user_id= ?";
    const sqlDeleteTeam = "DELETE FROM teams WHERE team_id=?";
    const sqlCaptain = "SELECT captain_id FROM teams WHERE team_id = ?"
    const sqlOtherCaptain = "SELECT user_id FROM users WHERE team_id = ?"
    const updateCaptain = "UPDATE teams SET captain_id=? WHERE team_id=?"
    db.query(sqlSearch, id, (err, result1) => {
        db.query(sqlUpdate, [null, id], (err, result2) => {
            if (err) {
                console.log(err);
                res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                throw err;
            }
            else {
                db.query(sqlDeleteSolves, [id], (err, result3) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                        throw err;
                    }
                    else {
                        if (result1.length > 1) {
                            db.query(sqlCaptain, result1[0].team_id, (err, result4) => {
                                if (err) {
                                    console.log(err);
                                    res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                    throw err;
                                }
                                else {
                                    if (result4[0].captain_id == id) {
                                        db.query(sqlOtherCaptain, result1[0].team_id, (err, result5) => {
                                            if (err) {
                                                console.log(err);
                                                res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                                throw err;
                                            }
                                            else {
                                                db.query(updateCaptain, [result5[0].user_id, result1[0].team_id], (err, result6) => {
                                                    if (err) {
                                                        console.log(err);
                                                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                                        throw err;
                                                    }
                                                    else {
                                                        res.send({ messageSuccess: "Usuario retirado del equipo" });
                                                    }

                                                })
                                            }
                                        })

                                    } else {
                                        res.send({ messageSuccess: "Usuario Eliminado!" });

                                    }
                                }

                            })
                        }
                        else {
                            db.query(sqlDeleteTeam, result1[0].team_id, (err, result4) => {
                                if (err) {
                                    console.log(err);
                                    res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                    throw err;
                                }
                                else {
                                    res.send({ messageSuccess: "Equipo y usuario Eliminado!" });
                                }

                            })
                        }

                    }

                })
            }

        })
    })

});
router.get("/getTeamMembersAdmin/:id", verifyToken, isAdmin, (req, res) => {
    const id = req.params.id;
    const sqlSelectUsers = 'SELECT users.user_id,users.username from users WHERE users.team_id=?  ';
    const sqlSelectMembersSolves = 'SELECT users.user_id, users.username, SUM(challenges.value) as score FROM solves INNER JOIN users ON solves.user_id=users.user_id INNER JOIN challenges ON solves.challenge_id=challenges.challenge_id WHERE solves.team_id=? GROUP BY users.user_id ORDER BY score DESC';
    const sqlSelectCaptain = "SELECT captain_id FROM teams WHERE team_id=?"
    db.query(sqlSelectUsers, id, (err, result2) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            db.query(sqlSelectCaptain, id, (err, result1) => {
                if (err) {
                    console.log(err);
                    res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                    throw err;
                }
                else {
                    db.query(sqlSelectMembersSolves, id, (err, result3) => {
                        if (err) {
                            console.log(err);
                            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                            throw err;
                        }
                        else {
                            var finalResult = [];
                            for (i in result2) {
                                let inResult = false;
                                let position = 0;
                                for (j in result3) {
                                    if (result2[i].username == result3[j].username) {
                                        inResult = true;
                                        position = j;
                                    }
                                }
                                if (inResult) {
                                    if (result1[0].captain_id == result3[i].user_id) {
                                        finalResult.push({ id: result3[position].user_id, username: result3[position].username, type: "Capitan", score: result3[position].score });
                                    }
                                    else {
                                        finalResult.push({ id: result3[position].user_id, username: result3[position].username, type: "Miembro", score: result3[position].score });
                                    }
                                }
                                else {
                                    if (result1[0].captain_id == result2[i].user_id) {
                                        finalResult.push({ id: result2[i].user_id, username: result2[i].username, type: "Capitan", score: 0 });
                                    }
                                    else {
                                        finalResult.push({ id: result2[i].user_id, username: result2[i].username, type: "Miembro", score: 0 });
                                    }
                                }
                            }
                            res.send(finalResult);
                        }

                    })
                }

            })
        }


    })
})
router.get("/getTeamAdmin", verifyToken, isAdmin, (req, res) => {

    const sqlSelect = "SELECT  teams.team_id,teams.name,SUM(challenges.value) as score, MAX(solves.created)as fecha FROM solves INNER JOIN challenges ON challenges.challenge_id = solves.challenge_id INNER JOIN teams ON teams.team_id = solves.team_id GROUP BY solves.team_id ORDER BY score DESC, fecha ASC"

    db.query("SELECT team_id, name FROM teams", (err, result1) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            db.query(sqlSelect, (err, result2) => {
                if (err) {
                    console.log(err);
                    res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                    throw err;
                }
                else {
                    if (result2.length > 0) {
                        let scoreboard = [];
                        for (let i = 0; i < result2.length; i++) {
                            scoreboard.push({ team_id: result2[i].team_id, name: result2[i].name, score: result2[i].score });
                        }
                        let countPlace = scoreboard[scoreboard.length - 1].place;
                        for (let j = 0; j < result1.length; j++) {
                            let found = false;
                            for (let h = 0; h < scoreboard.length; h++) {
                                if (scoreboard[h].name == result1[j].name) {
                                    found = true;
                                }
                            }
                            if (!found) {
                                countPlace++;
                                scoreboard.push({ team_id: result1[j].team_id, name: result1[j].name, score: 0 });
                            }
                        }

                        res.send(scoreboard);
                    }
                    else {
                        if (result1.length > 0) {
                            let scoreboard2 = [];
                            for (let h = 0; h < result1.length; h++) {
                                scoreboard2.push({ team_id: result1[h].team_id, name: result1[h].name, score: 0 });                            
                            }
                            res.send(scoreboard2);
                        }
                        else {
                            res.send([{ team_id: 0, name: 'No se ha creado ningún equipo', score: 0 }]);
                        }
                    }
                }

            });
        }
    });
})
module.exports = router;