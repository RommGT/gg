const express = require('express');
const router = express.Router();
const db = require("../database");
const jwt = require("jsonwebtoken");
const { verifyToken } = require('../middleware/auth');
const { verifyTime } = require('../middleware/time');
const jwt_decode = require('jwt-decode');
const { format } = require('date-fns-tz')

router.get("/getActiveCategories", verifyToken, verifyTime, (req, res) => {
    const sqlSelect = "select categories.title, categories.description, categories.location, categories.category_id from categories"
    const sqlSelectChallenges = "SELECT categories.category_id, COUNT(*) as count from challenges INNER JOIN categories ON categories.category_id=challenges.category_id WHERE challenges.state='visible' GROUP BY categories.category_id"
    const sqlTeam = "SELECT team_id FROM users where username = ?";
    const sqlSelectSolves = "SELECT challenges.category_id, COUNT(*) as count FROM solves INNER JOIN challenges ON solves.challenge_id=challenges.challenge_id WHERE team_id=? GROUP BY challenges.category_id"
    const user = jwt_decode(req.headers['authorization']);
    db.query(sqlSelect, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            db.query(sqlSelectChallenges, (err, result2) => {
                if (err) {
                    console.log(err);
                    res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                    throw err;
                }
                else {
                    db.query(sqlTeam, [user.username], (err, result3) => {
                        if (err) {
                            console.log(err);
                            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                            throw err;
                        }
                        else {
                            if (result3[0].team_id != null) {
                                db.query(sqlSelectSolves, result3[0].team_id, (err, result4) => {
                                    if (err) {
                                        console.log(err);
                                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                        throw err;
                                    }
                                    else {
                                        const resInfo = [];
                                        const resTotal = [];
                                        const resSolves = [];
                                        for (i in result) {
                                            let numChallenges = 0;
                                            for (j in result2) {
                                                if (result[i].category_id == result2[j].category_id) {
                                                    numChallenges = result2[j].count;
                                                }
                                            }
                                            resTotal.push([numChallenges])
                                        }
                                        for (k in result) {
                                            let numSolves = 0;
                                            for (h in result4) {
                                                if (result[k].category_id == result4[h].category_id) {
                                                    numSolves = result4[h].count;
                                                }
                                            }
                                            resSolves.push([numSolves])
                                        }

                                        for (l in result) {
                                            resInfo.push({
                                                title: result[l].title,
                                                description: result[l].description,
                                                location: result[l].location,
                                                category_id: result[l].category_id,
                                                totalChallenges: parseInt(resTotal[l]),
                                                totalSolves: parseInt(resSolves[l])
                                            });
                                        }
                                        res.send(resInfo);

                                    }
                                });

                            }
                            else {
                                const resInfo = [];
                                const resTotal = [];
                                const resSolves = [];
                                for (i in result) {
                                    let numChallenges = 0;
                                    for (j in result2) {
                                        if (result[i].category_id == result2[j].category_id) {
                                            numChallenges = result2[j].count;
                                        }
                                    }
                                    resTotal.push([numChallenges])
                                }
                                for (l in result) {
                                    resInfo.push({
                                        title: result[l].title,
                                        description: result[l].description,
                                        location: result[l].location,
                                        category_id: result[l].category_id,
                                        totalChallenges: parseInt(resTotal[l]),
                                        totalSolves: 0
                                    });
                                }
                                res.send(resInfo);
                            }
                        }
                    });
                }
            });
        }
    });
});

router.post("/getChallengesCategory", verifyToken, verifyTime, (req, res) => {
    const user_id = jwt_decode(req.headers['authorization'])
    const category = req.body.category_id;
    db.query("SELECT challenges.challenge_id, challenges.name,challenges.description, challenges.link, challenges.value, categories.title, challenges.location, challenges.state, challenges.icon FROM challenges INNER JOIN categories ON challenges.category_id=categories.category_id WHERE (state= 'visible'  AND challenges.category_id=?)",
        category, (err, result) => {
            if (err) {
                console.log(err);
                res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                throw err;
            }
            else {
                res.send(result)
            }
        });
});
router.post("/getHints", verifyToken, verifyTime, (req, res) => {
    const user_id = jwt_decode(req.headers['authorization'])
    const challenge_id = req.body.challenge_id;
    const sqlSelectHint = "SELECT hints.hint_id, hints.cost FROM hints WHERE challenge_id=?"
    const sqlSelectTeam = "SELECT team_id FROM users WHERE user_id=?"
    db.query(sqlSelectTeam, user_id.id, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "No pertences a un equipo!" });

            throw err;
        }
        else {
            if (result[0].team_id != null) {
                db.query(sqlSelectHint, challenge_id, (err, result) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                        throw err;
                    }
                    else {
                        if (result.length > 0) {
                            const resInfo = [];
                            for (i in result) {
                                resInfo.push({
                                    hint_id: result[i].hint_id,
                                    cost: result[i].cost,
                                    num: parseInt(i) + 1
                                });
                            }
                            res.send(resInfo)
                        }
                        else {
                            res.send([{ hint_id: 0, num: 0, cost: 0 }])
                        }
                    }
                });

            }
            else {
                res.send([{ hint_id: 0, num: 0, cost: 0 }]);
            }

        }
    });

});
router.post("/getOpenHint", verifyToken, verifyTime, (req, res) => {
    const user_id = jwt_decode(req.headers['authorization'])
    const hint_id = req.body.hint_id;
    const sqlSelectTeam = "SELECT team_id FROM users WHERE user_id=?"
    const sqlSelectOpen = "SELECT * FROM openHints WHERE hint_id=? and team_id=?"
    const sqlSelect = "SELECT hints.hint_id, hints.cost, hints.hint FROM hints WHERE hints.hint_id=?"
    db.query(sqlSelectTeam, user_id.id, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "No pertences a un equipo!" });
            throw err;
        }
        else {
            if (result[0].team_id != null) {
                db.query(sqlSelectOpen, [hint_id, result[0].team_id], (err, result2) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                        throw err;
                    }
                    else {
                        if (result2.length > 0) {
                            db.query(sqlSelect, hint_id, (err, result3) => {
                                if (err) {
                                    console.log(err);
                                    res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                    throw err;
                                }
                                else {
                                    res.send(result3)
                                }
                            });
                        }
                        else {
                            res.send({ messageError: "No puedes abrir esta pista!" });
                        }
                    }
                });

            }
            else {
                res.send({ messageError: "No pertences a un equipo!" });
            }
        }
    });
});
router.post('/getNewHint', verifyToken, verifyTime, (req, res) => {
    const user_id = jwt_decode(req.headers['authorization'])
    const hint_id = req.body.hint_id;
    const sqlSelectTeam = "SELECT team_id FROM users WHERE user_id=?"
    const sqlInsertOpen = "INSERT INTO openHints (hint_id,user_id, team_id,created) VALUES (?,?,?,?)"
    const sqlSelect = "SELECT hints.hint_id, hints.cost, hints.hint FROM hints WHERE hints.hint_id=?"
    const today = new Date();
    const pattern = 'yyyy-MM-d HH:mm:ss'
    const date = format(today, pattern, { timeZone: 'America/Guayaquil' });
    db.query(sqlSelectTeam, user_id.id, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "No pertences a un equipo!" });
            throw err;
        }
        else {
            if (result[0].team_id != null) {
                db.query(sqlInsertOpen, [hint_id, user_id.id, result[0].team_id, date], (err, result3) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                        throw err;
                    }
                    else {
                        db.query(sqlSelect, hint_id, (err, result4) => {
                            if (err) {
                                console.log(err);
                                res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                throw err;
                            }
                            else {
                                res.send(result4)
                            }
                        });
                    }
                });

            }
            else {
                res.send({ messageError: "No pertences a un equipo!" });
            }
        }
    });

});
router.get('/solvedChallenges', verifyToken, verifyTime, function (req, res) {
    const user = jwt_decode(req.headers['authorization'])

    db.query('SELECT team_id FROM users WHERE user_id=?', user.id, (err, result1) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result1.length > 0) {
                db.query("SELECT team_id, challenge_id FROM solves WHERE team_id=?", [result1[0].team_id], (err, result2) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                        throw err;
                    } else {
                        if (result2.length > 0) {
                            res.send(result2)
                        }
                        else {
                            res.send({ messageError: "No has resuelto ningún reto" });
                        }
                    }
                });
            }
            else {
                res.send({ messageError: "No has resuelto ningún reto" });
            }
        }
    });
});
router.post('/challengeSolve', verifyToken, verifyTime, function (req, res) {
    const user_id = jwt_decode(req.headers['authorization'])
    const { id, solve } = req.body;
    if (!solve) {
        res.send({ messageError: "Por favor ingresa la flag!" });
    } else {
        db.query("SELECT state,flag from challenges WHERE challenge_id=?", id, (err, result1) => {
            if (err) {
                console.log(err);
                res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                throw err;
            }
            else {
                if (result1.length > 0) {
                    if (result1[0].state === 'visible') {
                        db.query("SELECT team_id from users WHERE user_id=?;", [user_id.id], (err, response) => {
                            if (response[0].team_id !== null) {
                                db.query("SELECT team_id, user_id FROM solves WHERE solves.team_id=? AND solves.challenge_id=?;", [response[0].team_id, id], (err, response2) => {
                                    if (err) {
                                        console.log(err);
                                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                        throw err;
                                    }
                                    else {
                                        if (response2.length > 0) {
                                            res.send({ messageSuccess: "Ya has resuelto este reto!" })

                                        } else {
                                            var contSolve = "";
                                            contSolve = (result1[0].flag)
                                            if (contSolve === solve) {
                                                db.query("SELECT team_id FROM users WHERE user_id=?", [user_id.id], (err, result2) => {//el id
                                                    if (err) {
                                                        console.log(err);
                                                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                                        throw err;
                                                    } else {
                                                        const today = new Date();
                                                        const pattern = 'yyyy-MM-d HH:mm:ss'
                                                        const date = format(today, pattern, { timeZone: 'America/Guayaquil' });
                                                        db.query("INSERT INTO solves (challenge_id, user_id, team_id, created) VALUES(?,?,?,?)", [id, user_id.id, result2[0].team_id, date], (err, result3) => {
                                                            if (err) {
                                                                console.log(err);
                                                                res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                                                throw err;
                                                            } else {

                                                                res.send({ messageSuccess: "Buen trabajo!. Reto Resuelto." })
                                                            }
                                                        })
                                                    }
                                                })

                                            }
                                            else {
                                                res.send({ messageError: "La flag es incorrecta. Intenta de nuevo!" })
                                            }




                                        }
                                    }
                                });
                            }
                            else {
                                res.send({ messageError: "No tienes equipo. Unete a uno e intenta de nuevo!" })
                            }
                        });

                    }
                    else {
                        res.send({ messageError: "El reto no esta disponible. " })
                    }
                }
                else {
                    res.send({ messageError: "Ocurrio un error intente mas tarde. " })
                }
            }


        });
    }

});

module.exports = router;