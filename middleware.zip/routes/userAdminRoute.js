const express = require('express');
const router = express.Router();
const bcrypt = require("bcrypt");
const db = require("../database");
const {verifyToken, isAdmin} = require('../middleware/auth');
router.get("/getUsers",  verifyToken, isAdmin,(req, res) => {
    const sqlSelect = "SELECT user_id,name,username,email,type FROM users";
    db.query(sqlSelect, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            res.send(result);
        }
    });
});

router.post("/insertUsers", verifyToken, isAdmin, (req, res) => {
    const name = req.body.name;
    const username = req.body.username;
    const email = req.body.email;
    const type = req.body.type ? req.body.type : 'user';
    const password = req.body.password;
    const today = new Date();
    const date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    const time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    const dateTime = date + ' ' + time;

    const sqlInsert = "INSERT INTO users (name,username,email,type,password,created) VALUES (?,?,?,?,?,?)";
    bcrypt.hash(password, 10, (err, hash) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            db.query("SELECT * FROM users WHERE username = ?", [username], (err, result) => {
                if (result.length > 0) {
                    if (result[0].username == username) {
                        res.send({ messageError: "El usuario ya existe!" });
                    }
                }
                else {
                    db.query(
                        sqlInsert,
                        [name, username, email, type, hash, dateTime],
                        (err, result) => {
                            if (err) {
                                console.log(err);
                                res.send({ messageError: "Ocurrió un error! Intente más tarde" })
                                throw err;
                            } else { res.send({ messageSuccess: "Usuario Creado Exitosamente!" }); }
                        });
                }
            });
        }


    });
});
router.delete('/deleteUser/:id',  verifyToken, isAdmin,(req, res) => {
    const id = req.params.id;
    const sqlDelete = "DELETE FROM users WHERE user_id= ?";
    if(id==1){
        res.send({ messageError: "No se puede eliminar este usuario!" });       
    }
    else{
        db.query(sqlDelete, id, (err, result) => {
            if (err) {
                console.log(err);
                res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                throw err;
            }
            else {
                res.send({ messageSuccess: "Usuario Eliminado" });
            }
        });
    }
   
 
});

router.put('/updateUser', verifyToken, isAdmin, (req, res) => {
    const name = req.body.name;
    const username = req.body.username;
    const id = req.body.id.ide;
    const email = req.body.email;
    const type = req.body.type;
    const password = req.body.password;
    const sqlUser = "SELECT * FROM users WHERE username = ?";
    const sqlSelect = "SELECT * FROM users WHERE user_id = ?";
    const sqlUpdate = "UPDATE users SET name=?,username=?,email=?,type=?,password=? WHERE user_id=?";
    db.query(sqlUser, username, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result.length > 0) {
                if (result[0].username == username) {
                    res.send({ messageError: "El usuario ya existe!" });
                }
            }
            else {
                db.query(sqlSelect, id, (err, result) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                        throw err;
                    }
                    else {
                        if (result.length > 0) {
                            const name2 = result[0].name;
                            const username2 = result[0].username;
                            const email2 = result[0].email;
                            const type2 = result[0].type;
                            const password2 = result[0].password;
                            bcrypt.hash(password, 10, (err, hash) => {
                                if (err) {
                                    console.log(err);
                                    res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                    throw err;
                                }
                                else {
                                    db.query(sqlUpdate, [name ? name : name2, username ? username : username2, email ? email : email2, type ? type : type2, password ? hash : password2, id], (err, result) => {
                                        if (err) {
                                            console.log(err);
                                            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                            throw err;
                                        }
                                        else {
                                            res.send({ messageSuccess: "Usuario Actualizado" });
                                        }
                                    });
                                }
                            });

                        }
                        else {
                            res.send({ messageError: "El usuario no existe!" });
                        }
                    }
                });
            }
        }
    });

})

module.exports = router;