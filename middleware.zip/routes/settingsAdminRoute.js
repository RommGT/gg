const express = require('express');
const router = express.Router();
const { verifyToken, isAdmin } = require('../middleware/auth');
const verifyTime = require('../middleware/time');
const db = require("../database");
const { format } = require('date-fns-tz')

//TIME
router.put("/updateTimeConfig", verifyToken, isAdmin, (req, res) => {
    const startDate = new Date(req.body.startDate);
    const endDate = new Date(req.body.endDate);
    const showTime = req.body.showTime;
    const pattern = 'yyyy-MM-d HH:mm:ss'
    const dateStart = format(startDate, pattern, { timeZone: 'Americas/Guayaquil' });
    const dateEnd = format(endDate, pattern, { timeZone: 'Americas/Guayaquil' });
    const sqlUpdate = "UPDATE settings SET startDate= ?, endDate= ?, showTime=? WHERE setting_id=1 "
    db.query(sqlUpdate, [dateStart, dateEnd, String(showTime)], (err, result) => {
        if (err) {
            console.log(err);
            res.status(500).send({
                messageError: "Error al actualizar la configuración"
            })
        }
        else {
            res.status(200).send({
                messageSuccess: "configuración actualizada!"
            })
        }

    })
});
router.put('/adminHeaderInfo',verifyToken, isAdmin, (req, res) => {
    const { title, content } = req.body;
    const sqlUpdate = "UPDATE settings SET title=?,content=?";
    db.query(sqlUpdate, [title, content], (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Error al actualizar la información" });
            throw err;
        }
        else {
            res.send({ messageSuccess: "Información actualizada" });
        }
    })
})
router.put('/resetTimeConfig', verifyToken, isAdmin,  (req, res) => {
    const sqlUpdate = "UPDATE settings SET startDate= now(), endDate= now(), showTime='false' WHERE setting_id=1 "
    db.query(sqlUpdate, (err, result) => {
        if (err) {
            console.log(err);
            res.status(500).send({
                messageError: "Error al actualizar la configuración"
            })
        }
        else {
            res.status(200).send({
                messageSuccess: "Configuración reiniciada!"
            })
        }
    });
});

router.put('/setCompetitionInfo', verifyToken, isAdmin, (req, res) => {
    const sqlUpdate = "UPDATE settings SET information=? WHERE setting_id=1 "
    db.query(sqlUpdate, [req.body.competitionInfo?req.body.competitionInfo:null], (err, result) => {
        if (err) {
            console.log(err);
            res.status(500).send({
                messageError: "Error al actualizar la configuración"
            })
        }
        else {
            res.status(200).send({
                messageSuccess: "Configuración actualizada!"
            })
        }
    });
});

router.get('/getCompetitionInfo', verifyToken, isAdmin, (req, res) => {
    const sqlSelectInfo = "SELECT information,title,content FROM settings WHERE setting_id=1 "
   
    db.query(sqlSelectInfo, (err, result) => {
       
        if (err) {
            console.log(err);
            res.status(500).send({
                messageError: "Error al actualizar la configuración"
            })
        }
        else {
            if(result[0].information){
                res.status(200).send({
                    competitionInfo: result[0].information,
                    title: result[0].title,
                    content: result[0].content
                })
            }else{
                res.status(200).send({
                    competitionInfo: null
                })
            }
        }
    });
});

router.get('/getDates', verifyToken, isAdmin,  (req, res) => {
    const sqlDate = "SELECT startDate, endDate, showTime from settings"
    db.query(sqlDate, (err, result) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error al obtener las fechas" })
        }
        else {      
            if(result.length > 0){
                const dateS = new Date(result[0].startDate);
                const dateE = new Date(result[0].endDate);
                const pattern = 'MM/d/yyyy HH:mm'
                const dateStart = format(dateS, pattern, { timeZone: 'Americas/Guayaquil' });
                const dateEnd = format(dateE, pattern, { timeZone: 'Americas/Guayaquil' });
                res.send({ dateStart: dateStart, dateEnd: dateEnd, showTime: result[0].showTime })
            }
            else{
                res.send({ messageError: "No se encontraron fechas" })
            }
        }
    })
})

router.get('/getQuizConfig', verifyToken, isAdmin, (req, res) => {
    const sqlSelectQuiz = "SELECT showQuizP,showQuizF,showQuizM,showQuizD FROM settings WHERE setting_id=1 "
   
    db.query(sqlSelectQuiz, (err, result) => {
       
        if (err) {
            console.log(err);
            res.status(500).send({
                messageError: "Error al seleccionar datos"
            })
        }
        else {
            res.status(200).send(result)
            
        }
    });
});
module.exports = router;