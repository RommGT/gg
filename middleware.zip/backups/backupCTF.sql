-- MySQL dump 10.13  Distrib 8.0.28, for Linux (x86_64)
--
-- Host: localhost    Database: udlactf
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `setting_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `information` longtext,
  `startDate` varchar(100) DEFAULT NULL,
  `endDate` varchar(100) DEFAULT NULL,
  `showTime` varchar(20) DEFAULT NULL,
  `code` varchar(100) DEFAULT NULL,
  `showQuizP` varchar(50) DEFAULT NULL,
  `showQuizF` varchar(50) DEFAULT NULL,
  `showQuizM` varchar(50) DEFAULT NULL,
  `showQuizD` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'IV Edición CAPTURE THE FLAG','Próximamente','<p style=\"text-align: left;\"><strong> Código de conducta de UDLACTF</strong></p><p style=\"text-align: justify;\"><br>    Las siguientes reglas deben seguirse en TODO MOMENTO cuando participe en UDLACTF. <br>    Al usar este sitio, usted acepta adherirse a estos términos incondicionalmente, la violación de estos términos puede resultar en la revocación de su acceso y/o la cancelación de su cuenta. UDLACTF se reserva el derecho de cancelar cuentas o revocar cualquier derecho de acceso a discreción del administrador, sin previo aviso.<br>    1. Atacar cualquier cosa que no sean los objetivos proporcionados está fuera del alcance. Estaremos monitoreando el CTF de cerca y revocaremos el acceso de cualquier persona que parezca estar intentando atacar el marcador, otros participantes o la infraestructura más allá de los objetivos proporcionados.<br>    2. Si se encuentra alguna actividad sospechosa, la autoridad se reserva el derecho de prohibir un equipo o usuario específico.<br>    3. Los intentos intencionales de interrumpir el CTF, piratear sistemas no deseados o piratear a otros participantes darán como resultado la terminación inmediata de su cuenta de UDLACTF.<br>    4. La descripción del reto le proporcionarán los puntos finales a los que puede apuntar. Para completar el desafío, no necesita apuntar a nada fuera del punto final provisto. No intente piratear nada que no sean los objetivos especificados proporcionados. <br>    5. Si no está seguro de si algo que desea probar está dentro del alcance, PREGUNTE primero enviando un mensaje a un miembro de la administración.<br>    6. Si sospecha que algo está roto o encuentra un error que desea informar, envíe un mensaje privado a un miembro del equipo de administración.</p>','2022-02-25 20:00:00','2022-02-26 01:00:00','true','89414168','true','true','false','false');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `challenges`
--

DROP TABLE IF EXISTS `challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `challenges` (
  `challenge_id` int NOT NULL AUTO_INCREMENT,
  `category_id` int DEFAULT NULL,
  `flag` text,
  `name` varchar(200) DEFAULT NULL,
  `description` text,
  `link` text,
  `value` int DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`challenge_id`),
  KEY `FK_category_id` (`category_id`),
  CONSTRAINT `FK_category_id` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenges`
--

LOCK TABLES `challenges` WRITE;
/*!40000 ALTER TABLE `challenges` DISABLE KEYS */;
INSERT INTO `challenges` VALUES (9,1,'udlaCTF{qr_c0d3}','QR','Hemos recibido una imagen, pero no hemos logrado recuperar lo que tiene, nos ayudas a resolverlo?','https://drive.google.com/file/d/1Tn2WRXDtCMGZIJJUsKYCp38zH5ryAKpK/view?usp=sharing',100,NULL,'visible','/imgChallenge/img6.jpg'),(10,1,'udlaCTF{St3g_udl4}','Easy Steg','Al descargar un archivo nos ha aparecido una imagen y en un bloc de notas nos dice que la clave está en frente de tus ojos, pero no hemos logrado obtener la clave.','https://drive.google.com/file/d/1rpuP70qwu6QUKEG6V0a-X6H5VZfqoIc9/view?usp=sharing',150,NULL,'visible','/imgChallenge/img1.jpg'),(11,1,'udlaCTF{34sy_st3g4n0gr4phy}','Pidief','Uno de los alumnos de la UDLA ha enviado un archivo pdf a un compañero en un examen, pero el profesor no logra ver nada extraño','https://drive.google.com/file/d/1eSBVmzljW07IaiVg-sU_mDTFtfikG1SW/view?usp=sharing',50,NULL,'visible','/imgChallenge/img14.jpg'),(12,1,'udlaCTF{4ud1o_f4k3}','MP3','Hemos recibido un archivo mp3, pero al querer escuchar nos marca un error. Nos ayudas a descubrir como reproducir el archivo?','https://drive.google.com/file/d/1_2VtKQq8WwRlWRh2Hj3GULX6k_WfJymu/view?usp=sharing',200,NULL,'visible','/imgChallenge/img32.jpg'),(13,2,'udlaCTF{easy_cipher}','Easy Cripto','Este es uno de los retos mas fáciles para comenzar en el mundo de la criptografía\nxgodFWI{hdvb_flskhu}','',50,NULL,'visible','/imgChallenge/img5.jpg'),(14,2,'udlaCTF{f4k3_1s_r34l}','Pretty Good Privacy','Hemos recibido un txt con algo adentro pero no hemos podido descifrarlo. Nos ayudas?','https://drive.google.com/file/d/1tFH8h7agwBNxy_5YIjwbML8ZMUBVSfCR/view?usp=sharing',150,NULL,'visible','/imgChallenge/img17.jpg'),(15,2,'udlaCTF{f4k3_l1st}','Lista de Compras','Hemos interceptado la comunicación entre dos delincuentes cibernéticos, pudimos recuperar un archivo que fue enviado que al parecer contiene instrucciones para su próximo ataque, sin embargo al abrirlo nos encontramos una lista de compras. Según nuestro primer análisis es una forma de comunicarse de forma secreta entre ellos. ¿Puedes ayudarnos a descifrar el mensaje?','https://drive.google.com/file/d/1sD86rFtyEsgmNUVMQHZJ6YWu1RZuWEx4/view?usp=sharing',100,NULL,'visible','/imgChallenge/img25.jpg'),(16,2,'udlaCTF{enigma_machine}','Dota 2','Existe un videojuego llamado Dota2, este video juego se trata de destruir la base enemiga y tiene varios héroes por elegir pero en particular existe uno que es uno de mis favoritos que se llama Enigma. la flag entre {} y separa las palabras con (\' _ \') No olvidar que la flag se pone con udlaCTF{}    mjyhy gglhl oftkx xxzud','',200,NULL,'visible','/imgChallenge/img26.jpg'),(17,2,'udlaCTF{cipher_is_funny}','Next to César','Este es uno de los retos mas clasicos que se han visto hasta la actualidad\ndonde los alumnos de la carrera en Tecnologias de la Informacion deberan encontrar\nla clave, muchas esta clave nos puede ser de mucha utilidad\nnleiVBY{kbxamk_ql_nnvgg}','',200,NULL,'visible','/imgChallenge/img8.jpg'),(18,10,'udlaCTF{4LM0RS3M0S}','sistema de codificación','Nos han enviado un archivo un poco extraño, y no sabemos el significado. No olvidar que la flag empieza por udlaCTF{}','https://drive.google.com/file/d/1_RsDBQhD-H1IxARhDa0sZbagYeCA19HA/view?usp=sharing',50,NULL,'visible','/imgChallenge/img31.jpg'),(19,10,'udlaCTF{N4VY}','Flags','Hemos recibido un archivo pdf, que únicamente tiene una imagen de algunas banderas. No olvides que la flag empieza por udlaCTF{MAYUSCULAS}','https://drive.google.com/file/d/1XcZ2Q2hon21v5E0wKxcMwC9TOMhRdn8O/view?usp=sharing',50,NULL,'visible','/imgChallenge/img21.jpg'),(20,10,'udlaCTF{sp4c3s}','Espacios','En el archivo que ha enviado un estudiante hemos visto que no contiene nada pero el asegurar que no esta vacío.','https://drive.google.com/file/d/1D_glKa8sUpQER6oZQZNIRAwGeJGaAn4V/view?usp=sharing',100,NULL,'visible','/imgChallenge/img8.jpg'),(21,6,'udlaCTF{h3x4d3cima1}','Ing. Hextor','Ayúdanos a resolver este reto porfavor nos enviado el Ing. Hextor.  No olvidar que el formato de la FLAG es udlaCTF{}','https://drive.google.com/file/d/1D_ceKA25m9I4FsERYHGi-Sl1Hg4EbROz/view?usp=sharing',300,NULL,'visible','/imgChallenge/img9.jpg'),(22,6,'udlaCTF{b4s3s}','Bases de Hacking','En un curso que dura 62 horas sobre las bases de hacking nos dieron\nuna cadena de caracteres que no sabemos que significa, nos ayudas\na resolverlo?  No olvidar que el formato de la FLAG es udlaCTF{}','https://drive.google.com/file/d/1UglvP7wKGXuq29QKjvnkGItil43-sXyw/view?usp=sharing',150,NULL,'visible','/imgChallenge/img3.jpg'),(23,6,'udlaCTF{bin4ry}','Fundamentos','Ayúdanos a descubrir el mensaje oculto.  No olvides que el formato de la flag es udlaCTF{}','https://drive.google.com/file/d/1hcpZnHmDEo2IKkpYjFOEAcAidDx69ggk/view?usp=sharing',50,NULL,'visible','/imgChallenge/img7.jpg'),(26,7,'udlaCTF{good_revers1ng}','EXE extraño','Hemos descargado un archivo que al parecer solo imprime un mensaje, ayudanos a interpretar el mensaje y descubrir lo que oculta. Formato: udlaCTF{**************}','https://drive.google.com/file/d/1XNDRY6aHjzx0m-RNXT8Re2m_XiqCWOHK/view?usp=sharing',100,NULL,'visible','/imgChallenge/img29.jpg'),(27,12,'udlaCTF{PlataformaUDLACTF}','La encuesta','Consideramos que tu opinión es importante y nos va a ayudar a mejorar la plataforma. Por lo cual, te dejamos el link para contestar una encuesta. Es importante considerar que todo tu equipo tiene que contestar la encuesta para hacer válido este reto.','https://forms.gle/AeqjmYuAPnwXUymk8',150,NULL,'visible','/imgChallenge/img11.jpg'),(28,11,'udlaCTF{forense_es_facil}','Forense Facil','Hemos recibido una imagen de una USB, pero al analizarla los archivo no hemos detectado nada, nos ayuda a revisar que contiene? Recuerda que el formato de la FLAG es udlaCTF{}, Adicional para este reto debes tomar en cuenta que la imagen del USB pesa cerca de 10GB','https://drive.google.com/file/d/1_BrSvtjCP9bVHlk_Akm1S1QjiuL0Ekad/view?usp=sharing',100,NULL,'visible','/imgChallenge/img7.jpg'),(29,3,'udlaCTF{UDLA_Colón}','Easy Osint','Nos han dado esta imagen, y no podemos encontrarnos con el nombre para resolver este reto, tomar en cuenta que el formato es udlaCTF{*_*} donde los *  representan palabras.','https://drive.google.com/file/d/1XWREFJygipr6eginJbxafmyg79vKNvhR/view?usp=sharing',100,NULL,'visible','/imgChallenge/img31.jpg'),(30,3,'udlaCTF{-0.16,-78.47}','Granados','Cerca de la Universidad de las Américas en la sede de los Granados hay varios lugares comerciales, de igual forma hay sitio para tomar el bus, mi amigo me dice que el siempre toma el bus en la parada en la calle que está al frente de la Universidad, el vive cerca de mi casa y quiero tomar el mismo bus pero no encuentro donde se ubica la parada. Si es necesario puedes separar por \' , \'  . Toma en cuenta que el formato de la flag es udlaCTF{*,*} donde los asteriscos representan números de dos decimales (ejm: 2.12) y se toma en cuenta los signos matemáticos.','',150,NULL,'visible','/imgChallenge/img29.jpg'),(31,8,'udlaCTF{mULT1pl3_Compress_F1l3s}','MultiArchivos','Nos han dejado este archivo comprimido que contiene la flag en el primer archivo, dicen que se puede descomprimir manualmente pero me llevaría mucho tiempo, le pregunte a un amigo y me dijo que solo bashta con saber un poco de programación.','https://drive.google.com/file/d/107OBOW6akYRb2Zqhavu9QyGzXv8bSJT1/view?usp=sharing',350,NULL,'visible','/imgChallenge/img13.jpg'),(32,8,'udlaCTF{J4v4_0fusc4d0r}','Easy Progra','Hemos recibido un archivo txt en el cual esta escrito algo extraño el cual no entendemos parece que cambiaron de alguna manera para que sea difícil de leer, por favor ayúdanos a descubrir que dice. ','https://drive.google.com/file/d/1FdgojXVbC6vLZJfkVw40VRzNDGBh2hZV/view?usp=sharing',300,NULL,'visible','/imgChallenge/img2.jpg');
/*!40000 ALTER TABLE `challenges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teams` (
  `team_id` int NOT NULL AUTO_INCREMENT,
  `captain_id` int DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES (30,55,'D.A.M','$2b$10$AyG8ai2Rq6AXglRaanBgFuivC5E80Aaf7yRI8cb9J4B73FPX6QJtC','2022-02-16 20:44:40'),(32,96,'LAS DIVAS','$2b$10$NlRnJ0Ag/t4WqtMAvjj8huh/cvHJecGdNDi.HopT/UdE.yyEnZtiy','2022-02-21 01:11:26'),(33,47,'Devil bots','$2b$10$hfEKsjMHo1DZ2Bqfb9uWoOReeI4yNhv7YvRbzUTkce4jlXLuq2WgW','2022-02-21 21:30:31'),(34,50,'D.M','$2b$10$vEyctTJaw2gRS0zcYJ.aeOHcajMXaL5Hej7FO7Mvl/1ITKT07rTOe','2022-02-21 22:39:31'),(35,107,'Los posi del A','$2b$10$D2NkLk8Hftr9OFroAf3EKunPWTo3qVP1hv96qPTAHi0fraa/AX3LK','2022-02-22 22:43:39'),(37,74,'Los del final','$2b$10$egroqs9XdVOJ84o.ruLf8eS1ndxuNjzisPgD3YX5auP7KkKEmBFzi','2022-02-22 22:50:47'),(38,97,'T3cnology','$2b$10$ladl7ccK7fLGjAa6DkCTqeXw68xZPd7.MBcspRBNY7WeQcJTDxthG','2022-02-22 23:24:02'),(39,115,'Las_constelaciones','$2b$10$8XfSeQM.RyOVvGcFv5nvROmAV83MauUPH7/m52PV.azf2v8ZfC3ja','2022-02-22 23:55:30'),(40,123,'Delta','$2b$10$..BD5Rfd0NYYPEgFjt2mwe3GCN6/WUq.NTWfDWW/7VKbavOLyJpuu','2022-02-23 02:46:03');
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hints`
--

DROP TABLE IF EXISTS `hints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hints` (
  `hint_id` int NOT NULL AUTO_INCREMENT,
  `challenge_id` int DEFAULT NULL,
  `hint` text,
  `cost` int DEFAULT NULL,
  PRIMARY KEY (`hint_id`),
  KEY `FK_challengeHint_id` (`challenge_id`),
  CONSTRAINT `FK_challengeHint_id` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`challenge_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hints`
--

LOCK TABLES `hints` WRITE;
/*!40000 ALTER TABLE `hints` DISABLE KEYS */;
INSERT INTO `hints` VALUES (4,29,'google es tu mejor aliado cuando se trata de imágenes',10),(5,10,'Es mejor que confíes en tu vista',10),(6,30,'Normalmente separamos por , las coordenadas de un sitio',15),(7,15,'pista',10);
/*!40000 ALTER TABLE `hints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `openHints`
--

DROP TABLE IF EXISTS `openHints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `openHints` (
  `openHint_id` int NOT NULL AUTO_INCREMENT,
  `hint_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `team_id` int DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`openHint_id`),
  KEY `FK_hint_id` (`hint_id`),
  KEY `FK_userHint_id` (`user_id`),
  KEY `FK_teamHints_id` (`team_id`),
  CONSTRAINT `FK_hint_id` FOREIGN KEY (`hint_id`) REFERENCES `hints` (`hint_id`),
  CONSTRAINT `FK_teamHints_id` FOREIGN KEY (`team_id`) REFERENCES `teams` (`team_id`),
  CONSTRAINT `FK_userHint_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `openHints`
--

LOCK TABLES `openHints` WRITE;
/*!40000 ALTER TABLE `openHints` DISABLE KEYS */;
/*!40000 ALTER TABLE `openHints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solves`
--

DROP TABLE IF EXISTS `solves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `solves` (
  `solves_id` int NOT NULL AUTO_INCREMENT,
  `challenge_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `team_id` int DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`solves_id`),
  KEY `FK_challengeSolve_id` (`challenge_id`),
  KEY `FK_teamSolve_id` (`team_id`),
  CONSTRAINT `FK_challengeSolve_id` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`challenge_id`),
  CONSTRAINT `FK_teamSolve_id` FOREIGN KEY (`team_id`) REFERENCES `teams` (`team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solves`
--

LOCK TABLES `solves` WRITE;
/*!40000 ALTER TABLE `solves` DISABLE KEYS */;
/*!40000 ALTER TABLE `solves` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-23 19:05:15
