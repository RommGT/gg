const express = require('express');
const router = express.Router();
const db = require("../database");
const { spawn } = require("child_process");
const fs = require('fs')
const jwt = require("jsonwebtoken");
const { verifyToken, isAdmin } = require('../middleware/auth');
const { verifyTime } = require('../middleware/time');
const jwt_decode = require('jwt-decode');
const fileUpload = require('express-fileupload');
router.use(fileUpload());
var cookieParser = require('cookie-parser');
router.use(cookieParser());

router.post('/uploadFileChallenges', verifyToken,isAdmin, (req, res) => {

    if (req.files === null) {
        return res.status(400).json({ msg: 'No file uploaded' });
    }
    if (req.files.file.name != 'backupRetos.sql') {
        res.send({ messageError: "El archivo debe tener el mismo nombre del respaldo descargado!" })
    } else {
        const file = req.files.file;

        file.mv(`${__dirname}/uploads/${file.name}`, err => {
            if (err) {
                console.log(err)
                return res.status(500).send(err);
            }

            res.json({ fileName: file.name, filePath: `/uploads/${file.name}` });
        });
    }
});
router.post('/uploadFileCTF', verifyToken, isAdmin, (req, res) => {
    if (req.files === null) {
        return res.status(400).json({ msg: 'No file uploaded' });
    }
    if (req.files.file.name != 'backupCTF.sql') {
        res.send({ messageError: "El archivo debe tener el mismo nombre del respaldo descargado!" })
    } else {
        const file = req.files.file;

        file.mv(`${__dirname}/uploads/${file.name}`, err => {
            if (err) {
                console.log(err);
                return res.status(500).send(err);
            }

            res.json({ fileName: file.name, filePath: `/uploads/${file.name}` });
        });
    }
});
router.post('/uploadFileLearning', verifyToken, isAdmin, (req, res) => {
    if (req.files === null) {
        return res.status(400).json({ msg: 'No file uploaded' });
    }
    if (req.files.file.name != 'backupAprendizaje.sql') {
        res.send({ messageError: "El archivo debe tener el mismo nombre del respaldo descargado!" })
    } else {
        const file = req.files.file;

        file.mv(`${__dirname}/uploads/${file.name}`, err => {
            if (err) {
                console.log(err);
                return res.status(500).send(err);
            }

            res.json({ fileName: file.name, filePath: `/uploads/${file.name}` });
        });
    }
});
router.post('/uploadFileComplete', verifyToken, isAdmin, (req, res) => {
    if (req.files === null) {
        return res.status(400).json({ msg: 'No file uploaded' });
    }
    if (req.files.file.name != 'backupCompleto.sql') {
        res.send({ messageError: "El archivo debe tener el mismo nombre del respaldo descargado!" })
    } else {
        const file = req.files.file;

        file.mv(`${__dirname}/uploads/${file.name}`, err => {
            if (err) {
                console.log(err);
                return res.status(500).send(err);
            }

            res.json({ fileName: file.name, filePath: `/uploads/${file.name}` });
        });
    }
});
router.get('/backupCTF', verifyToken, isAdmin, (req, res) => {
    const backupCTF = spawn("mysqldump", ['-u', process.env.DB_USER, '--password=' + process.env.DB_PASSWORD,
        process.env.DB_DATABASE,
        '--tables',
        'settings',
        'challenges',
        'teams',
        'hints',
        'openHints',
        'solves'
    ])
    const writeStream = fs.createWriteStream("./backups/backupCTF.sql")
    backupCTF.stdout.pipe(writeStream);

    backupCTF.stderr.on("data", data => {

        console.log(`stderr: ${data}`)
    })
    backupCTF.on("error", (error) => {
        console.log(`error: ${error.message}`)
    })
    backupCTF.on("close", code => {
        console.log(`child process exited with code ${code}`);
        res.send({ messageDownload: "Descargar" })
    })

});
router.get('/backupCTFFile',(req,res) =>{
    const tokenCTF = req.cookies['tokenCTF'];
    jwt.verify(tokenCTF, process.env.SECRET_JWT, function(err, decoded) {
        if(err) res.send('TOKEN INVALIDO');
        if(decoded.type=='adminCTF21_UDLA!*'){
            const file = `${__dirname}/backupCTF.sql`;
            res.download(file);
        }
        else{
            res.send('ACCESO NO AUTORIZADO!');
        }
        
    });
    

});
router.get('/backupChallengesFile',(req,res) =>{
    const tokenCTF = req.cookies['tokenCTF'];
    jwt.verify(tokenCTF, process.env.SECRET_JWT, function(err, decoded) {
        if(err) res.send('TOKEN INVALIDO');
        if(decoded.type=='adminCTF21_UDLA!*'){
            const file = `${__dirname}/backupRetos.sql`;
             res.download(file);
        }
        else{
            res.send('ACCESO NO AUTORIZADO!');
        }
        
    });
    

});
router.get('/backupAprendizajeFile',(req,res) =>{
    const tokenCTF = req.cookies['tokenCTF'];
    jwt.verify(tokenCTF, process.env.SECRET_JWT, function(err, decoded) {
        if(err) res.send('TOKEN INVALIDO');
        if(decoded.type=='adminCTF21_UDLA!*'){
            const file = `${__dirname}/backupAprendizaje.sql`;
            res.download(file);
        }
        else{
            res.send('ACCESO NO AUTORIZADO!');
        }
        
    });
    

});
router.get('/backupCompletoFile',(req,res) =>{
    const tokenCTF = req.cookies['tokenCTF'];
    jwt.verify(tokenCTF, process.env.SECRET_JWT, function(err, decoded) {
        if(err) res.send('TOKEN INVALIDO');
        if(decoded.type=='adminCTF21_UDLA!*'){
            const file = `${__dirname}/backupCompleto.sql`;
            res.download(file);
        }
        else{
            res.send('ACCESO NO AUTORIZADO!');
        }
        
    });
  

});

router.get('/backupChallenges', verifyToken, isAdmin, (req, res) => {
    const backupCTF = spawn("mysqldump", ['-u', process.env.DB_USER, '--password=' + process.env.DB_PASSWORD,
        process.env.DB_DATABASE,
        '--tables',
        'challenges',
        'hints',
    ])
    const writeStream = fs.createWriteStream("./backups/backupRetos.sql")
    backupCTF.stdout.pipe(writeStream);

    backupCTF.stderr.on("data", data => {

        console.log(`stderr: ${data}`)
    })
    backupCTF.on("error", (error) => {
        console.log(`error: ${error.message}`)
    })
    backupCTF.on("close", code => {
        console.log(`child process exited with code ${code}`);
        res.send({ messageDownload: "Descargar" })
    })

});
router.get('/backupLearning',verifyToken, isAdmin, (req, res) => {
    const backupCTF = spawn("mysqldump", ['-u', process.env.DB_USER, '--password=' + process.env.DB_PASSWORD,
        process.env.DB_DATABASE,
        '--tables',
        'users',
        'writeups',
        'learning',
        'flags',
        'solvesLearn',
        'quiz',
        'solvesQuiz',
    ])
    const writeStream = fs.createWriteStream("./backups/backupAprendizaje.sql")
    backupCTF.stdout.pipe(writeStream);

    backupCTF.stderr.on("data", data => {

        console.log(`stderr: ${data}`)
    })
    backupCTF.on("error", (error) => {
        console.log(`error: ${error.message}`)
    })
    backupCTF.stdout.on("stdout", (data) => {
        console.log(`stdout: ${data}`)
    })
    backupCTF.on("close", code => {
        console.log(`child process exited with code ${code}`);
        res.send({ messageDownload: "Descargar" })
    })

});

router.get('/backupCompleto', verifyToken, isAdmin, (req, res) => {
    const backupCTF = spawn("mysqldump", ['-u', process.env.DB_USER, '--password=' + process.env.DB_PASSWORD,
        process.env.DB_DATABASE
    ])
    const writeStream = fs.createWriteStream("./backups/backupCompleto.sql")
    backupCTF.stdout.pipe(writeStream);

    backupCTF.stderr.on("data", data => {

        console.log(`stderr: ${data}`)
    })
    backupCTF.on("error", (error) => {
        console.log(`error: ${error.message}`)
    })
    backupCTF.on("close", code => {
        console.log(`child process exited with code ${code}`);
        res.send({ messageDownload: "Descargar" })
    })

});
router.get('/updateBackupChallenges', verifyToken, isAdmin, (req, res) => {
    const backupCTF = spawn("mysql", ['-u', process.env.DB_USER, '--password=' + process.env.DB_PASSWORD,
        process.env.DB_DATABASE
    ])
    backupCTF.stdin.write('\\. /home/udladmin/backend/backups/uploads/backupRetos.sql')
    backupCTF.stdin.end();
    backupCTF.stderr.on("data", data => {

        console.log(`stderr: ${data}`)
    })
    backupCTF.stdout.on("data", data => {

        console.log(`stderr: ${data}`)
    })
    backupCTF.on("error", (error) => {
        console.log(`error: ${error.message}`)
        res.send({ messageError: 'Se produjo un error' })
    })
    backupCTF.on("close", code => {
        console.log(`child process exited with code ${code}`);
        if (code == 0) {
            res.send({ messageSuccess: 'Se actualizo correctamente' })
        } else {
            res.send({ messageError: 'Se produjo un error' })
        }
    })

});
router.get('/updateBackupCTF', verifyToken, isAdmin, (req, res) => {
    const backupCTF = spawn("mysql", ['-u', process.env.DB_USER, '--password=' + process.env.DB_PASSWORD,
        process.env.DB_DATABASE
    ])
    backupCTF.stdin.write('\\. /home/udladmin/backend/backups/uploads/backupCTF.sql')
    backupCTF.stdin.end();
    backupCTF.stderr.on("data", data => {

        console.log(`stderr: ${data}`)
    })
    backupCTF.stdout.on("data", data => {

        console.log(`stderr: ${data}`)
    })
    backupCTF.on("error", (error) => {
        console.log(`error: ${error.message}`)
        res.send({ messageError: 'Se produjo un error' })
    })
    backupCTF.on("close", code => {
        console.log(`child process exited with code ${code}`);
        if (code == 0) {
            res.send({ messageSuccess: 'Se actualizo correctamente' })
        } else {
            res.send({ messageError: 'Se produjo un error' })
        }
    })

});
router.get('/updateBackupLearning', verifyToken, isAdmin, (req, res) => {
    const backupCTF = spawn("mysql", ['-u', process.env.DB_USER, '--password=' + process.env.DB_PASSWORD,
        process.env.DB_DATABASE
    ])
    backupCTF.stdin.write('\\. /home/udladmin/backend/backups/uploads/backupAprendizaje.sql')
    backupCTF.stdin.end();
    backupCTF.stderr.on("data", data => {

        console.log(`stderr: ${data}`)
    })
    backupCTF.stdout.on("data", data => {

        console.log(`stderr: ${data}`)
    })
    backupCTF.on("error", (error) => {
        console.log(`error: ${error.message}`)
        res.send({ messageError: 'Se produjo un error' })
    })
    backupCTF.on("close", code => {
        console.log(`child process exited with code ${code}`);
        if (code == 0) {
            res.send({ messageSuccess: 'Se actualizo correctamente' })
        } else {
            res.send({ messageError: 'Se produjo un error' })
        }
    })

});
router.get('/updateBackupComplete', verifyToken, isAdmin, (req, res) => {
    const backupCTF = spawn("mysql", ['-u', process.env.DB_USER, '--password=' + process.env.DB_PASSWORD,
        process.env.DB_DATABASE
    ])
    backupCTF.stdin.write('\\. /home/udladmin/backend/backups/uploads/backupCompleto.sql')
    backupCTF.stdin.end();
    backupCTF.stderr.on("data", data => {

        console.log(`stderr: ${data}`)
    })
    backupCTF.stdout.on("data", data => {

        console.log(`stderr: ${data}`)
    })
    backupCTF.on("error", (error) => {
        console.log(`error: ${error.message}`)
        res.send({ messageError: 'Se produjo un error' })
    })
    backupCTF.on("close", code => {
        console.log(`child process exited with code ${code}`);
        if (code == 0) {
            res.send({ messageSuccess: 'Se actualizo correctamente' })
        } else {
            res.send({ messageError: 'Se produjo un error' })
        }
    })

});
router.get("/getResultsCTF", verifyToken, isAdmin, (req, res) => {
    const sqlSelect = "SELECT  teams.team_id,teams.name,SUM(challenges.value) as score, MAX(solves.created)as fecha FROM solves INNER JOIN challenges ON challenges.challenge_id = solves.challenge_id INNER JOIN teams ON teams.team_id = solves.team_id GROUP BY solves.team_id ORDER BY score DESC, fecha ASC";
    const sqlSelectUser = "SELECT  user_id,team_id,name, username, email, institution, role FROM users";

    db.query(sqlSelect, (err, result1) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result1.length > 0) {
                db.query(sqlSelectUser, (err, result2) => {
                    if (err) {
                        console.log(err);
                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                        throw err;
                    }
                    else {
                        var data = 'Lugar\tEquipo\tPuntaje\n';
                        var data2 = '';
                        for (let i = 0; i < result1.length; i++) {
                            data = data + (i + 1) + '\t' + result1[i].name + '\t' + result1[i].score + '\n';
                            data2 = data2 + 'Equipo' + '\t' + result1[i].name + '\n';
                            data2 = data2 + 'Nombres' + '\t' + 'Usuarios' + '\t' + 'Correos' + '\t' + 'Institución' + '\t' + 'Rol/Materia' + '\n';
                            for (let j = 0; j < result2.length; j++) {
                                if (result1[i].team_id == result2[j].team_id) {
                                    data2 = data2 + result2[j].name + '\t' + result2[j].username + '\t' + result2[j].email + '\t' + result2[j].institution + '\t' + result2[j].role + '\n';
                                }
                            }
                            data2 = data2 + '\n\n';
                        }
                        var dataFinal = data + '\n\n\n\n' + data2;
                        fs.writeFile('./backups/resultadosCTF.xls', dataFinal, (err) => {
                            if (err) {
                                console.log(err);
                                throw err;
                            }
                            res.download('./backups/resultadosCTF.xls')
                        }
                        )
                    }
                })

            }
            else {
                res.send({ messageError: "No hay puntuaciones!" });
            }
        }
    });
})
router.get("/getResultsLearning", verifyToken, isAdmin, (req, res) => {
    const sqlSelect = "SELECT users.username, SUM(flags.score) AS score FROM solvesLearn INNER JOIN flags ON solvesLearn.flag_id = flags.flag_id INNER JOIN users ON solvesLearn.user_id = users.user_id GROUP BY users.username ORDER BY score DESC";
    const sqlSelectUser = "SELECT  username,name, email, institution, role FROM users";
    db.query(sqlSelect, (err, result1) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result1.length > 0) {
                db.query(sqlSelectUser, (err, result2) => {
                    if (err) {
                        res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                        throw err;
                    }
                    else {
                        var data = 'Posición\tUsuario\tPuntaje\tNombre\tEmail\tInstitución\tRol/Materia\n';
                        for (let i = 0; i < result1.length; i++) {
                            data = data + (i + 1) + '\t' + result1[i].username + '\t'
                                + result1[i].score;
                            for (let j = 0; j < result2.length; j++) {
                                if (result1[i].username == result2[j].username) {
                                    data = data + '\t' + result2[j].name + '\t' + result2[j].email +
                                        '\t' + result2[j].institution + '\t' + result2[j].role + '\n';
                                    break;
                                }
                            }
                        }

                        fs.writeFile('./backups/resultadosAprendizaje.xls', data, (err) => {
                            if (err) {
                                console.log(err);
                                throw err;
                            }
                            res.download('./backups/resultadosAprendizaje.xls')
                        })

                    }
                })

            }
            else {
                res.send({ messageError: "No hay puntuaciones de aprendizaje!" });
            }
        }
    });
})
router.get("/getResultsQuiz", verifyToken, isAdmin, (req, res) => {
    const sqlSelect = "select users.username,users.name,score,level from solvesQuiz INNER JOIN users WHERE solvesQuiz.user_id=users.user_id ORDER BY level";
    db.query(sqlSelect, (err, result1) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result1.length > 0) {
                var data = 'Usuario\tNombres\tNota\tNivel\n';
                for (let i = 0; i < result1.length; i++) {
                    data = data +  result1[i].username + '\t'
                        + result1[i].name + '\t'+result1[i].score+ '\t'+result1[i].level +  '\n';
                }

                fs.writeFile('./backups/resultadosPruebaAprendizaje.xls', data, (err) => {
                    if (err) {
                        console.log(err);
                        throw err;
                    }
                    res.download('./backups/resultadosPruebaAprendizaje.xls')
                })




            }
            else {
                res.send({ messageError: "No hay pruebas respondidas!" });
            }
        }
    });
})

router.get("/getUsers",verifyToken, isAdmin,(req, res) => {
    const sqlSelect = "SELECT * FROM users order by created ASC";
    db.query(sqlSelect, (err, result1) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            if (result1.length > 0) {
                var data = 'ID\tUsuario\tNombres\tEmail\tFecha de creacion\n';
                for (let i = 0; i < result1.length; i++) {
                    data = data +  result1[i].user_id + '\t'
                        + result1[i].username + '\t'+result1[i].name+ '\t'+result1[i].email +'\t'+result1[i].created+  '\n';
                }

                fs.writeFile('./backups/usuariosPlataforma.xls', data, (err) => {
                    if (err) {
                        console.log(err);
                        throw err;
                    }
                    res.download('./backups/usuariosPlataforma.xls')
                })




            }
            else {
                res.send({ messageError: "No hay pruebas respondidas!" });
            }
        }
    });
})
router.get("/resetCTF", verifyToken, isAdmin, (req, res) => {
    const deleteSolves = "DELETE FROM solves";
    const deleteOpenHints = "DELETE FROM openHints";
    const deleteTeams = "DELETE FROM teams";
    const updateSettings = "UPDATE settings SET title='Capture The Flag',content='Próximamente', startDate=now(), endDate=now(),showTime='false',code='23412345',showQuizP='false',showQuizF='false',showQuizM='false',showQuizD='false',information=?) ";
    const rules = '<p style="text-align: left;"><strong> Código de conducta de UDLACTF</strong></p>\
   <p style="text-align: justify;"><br>\
       Las siguientes reglas deben seguirse en TODO MOMENTO cuando participe en UDLACTF. <br>\
       Al usar este sitio, usted acepta adherirse a estos términos incondicionalmente, la violación de estos términos puede resultar en la revocación de su acceso y/o la cancelación de su cuenta. UDLACTF se reserva el derecho de cancelar cuentas o revocar cualquier derecho de acceso a discreción del administrador, sin previo aviso.<br>\
       1. Atacar cualquier cosa que no sean los objetivos proporcionados está fuera del alcance. Estaremos monitoreando el CTF de cerca y revocaremos el acceso de cualquier persona que parezca estar intentando atacar el marcador, otros participantes o la infraestructura más allá de los objetivos proporcionados.<br>\
       2. Si se encuentra alguna actividad sospechosa, la autoridad se reserva el derecho de prohibir un equipo o usuario específico.<br>\
       3. Los intentos intencionales de interrumpir el CTF, piratear sistemas no deseados o piratear a otros participantes darán como resultado la terminación inmediata de su cuenta de UDLACTF.<br>\
       4. La descripción del reto le proporcionarán los puntos finales a los que puede apuntar. Para completar el desafío, no necesita apuntar a nada fuera del punto final provisto. No intente piratear nada que no sean los objetivos especificados proporcionados. <br>\
       5. Si no está seguro de si algo que desea probar está dentro del alcance, PREGUNTE primero enviando un mensaje a un miembro de la administración.<br>\
       6. Si sospecha que algo está roto o encuentra un error que desea informar, envíe un mensaje privado a un miembro del equipo de administración.</p>';
    db.query(deleteSolves, (err, result1) => {
        if (err) {
            console.log(err);
            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
            throw err;
        }
        else {
            db.query(deleteOpenHints, (err, result2) => {
                if (err) {
                    console.log(err);
                    res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                    throw err;
                }
                else {
                    db.query(deleteTeams, (err, result3) => {
                        if (err) {
                            console.log(err);
                            res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                            throw err;
                        }
                        else {
                            db.query(updateSettings, rules, (err, result4) => {
                                if (err) {
                                    console.log(err);
                                    res.send({ messageError: "Ocurrió un error! Intente más tarde" });
                                    throw err;
                                }
                                else {
                                    res.send({ messageSuccess: 'Reinicio de CTF completado' })
                                }
                            })
                        }
                    })
                }
            })

        }
    });
})
module.exports = router;
