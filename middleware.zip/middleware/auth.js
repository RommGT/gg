const jwt = require("jsonwebtoken");
const db = require("../database");
const jwt_decode = require('jwt-decode')
require('dotenv').config();
const verifyToken = async (req, res, next) => {
    let tokenCTF = req.headers["authorization"];
    if (!tokenCTF) return res.send({ messageE: "No hay token", noAuth: true });

    try {
        const decoded = jwt.verify(tokenCTF, process.env.SECRET_JWT); //cambiar con envs
        req.userId = decoded.id;
        const user = db.query("SELECT * FROM users WHERE user_id = ?", [req.userId], (err, result) => {
            if (err) { 
                console.log(err);
                res.send({ messageE: "Ocurrió un error! Intente más tarde", noAuth: true}); 
                throw err; }
            else {
                if (result.length > 0) {
                    return true;
                } else {
                    return false;
                }
            }
        });
        if (!user) return res.send({ messageE: "Usuario no encontrado!" , noAuth: true});

        next();
    } catch (error) {
        console.log(error);
        return res.send({ messageE: "No tiene autorización!" , noAuth: true});
    }
};

const isAdmin = async (req, res, next) => {
    try {
        let tokenCTF = req.headers["authorization"];
        const user = jwt_decode(tokenCTF);
        db.query("SELECT * FROM users WHERE user_id = ?", [user.id], (err, result) => {
            if (err) {
                console.log(err);
                res.send({ messageE: "Ocurrió un error! Intente más tarde", noAdmin: true });
                throw err;
            }
            else{
                if(result[0].type== 'adminCTF21_UDLA!*'){
                    next();
                    return;
                }else{
                    return res.send({ messageE: "No eres administrador!", noAdmin: true});
                }
            }
        })
    } catch (error) {
        console.log(error);
        return res.send({ messageE: error , noAdmin: true});
    }
};

module.exports = { verifyToken, isAdmin };