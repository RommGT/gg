const db = require("../database");


const verifyTime = async (req, res, next) => {
    try {
        db.query("SELECT startDate, endDate FROM settings", (err, result) => {
            if (err) {
                console.log(err);
                res.send({ messageE: "Ocurrió un error! Intente más tarde", noAuth: true });
                throw err;
            }
            else {
                if (result.length > 0) {
                    let startDate = new Date(result[0].startDate);
                    let endDate = new Date(result[0].endDate);
                    let now = new Date();
                    if (now > startDate && now < endDate) {
                        next();
                        return;
                    } else {
                        if(now > endDate){
                            return res.send({ messageFinish: true});
                        }
                        else if (now < startDate){
                            return res.send({ messageInit: true});
                        }
                        else{
                            return res.send({ messageNot: true});
                        }
                    }
                } else {
                    return res.send({ messageE: "Ocurrió un error! Intente más tarde" });
                }
            }
        })
    } catch (error) {
        console.log(error);
        return res.send({ messageE: error });
    }
};

module.exports = { verifyTime };