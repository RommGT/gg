const express = require("express");
require('dotenv').config();

const mysql = require("mysql");
const jwt = require("jsonwebtoken");
const http = require("http");
const https = require ("https");
const fs = require('fs');
//var privateKey  = fs.readFileSync('../localhost.key', 'utf8'); //change here
//var certificate = fs.readFileSync('../localhost.crt', 'utf8'); //change here
//var credentials = {key: privateKey, cert: certificate};
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
const users = require("./routes/userRoute");
const twitter = require("./routes/twitter");
const tiktok = require("./routes/tiktok");
const app = express();
const httpServer = http.createServer(app);
//const httpsServer = https.createServer(credentials,app);
app.use(express.json());
app.use(bodyParser.json({limit: '10000mb', extended: true}))
app.use(bodyParser.urlencoded({ limit: '10000mb' ,extended: true}));

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-COntrol-Allow-Request-Method');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
    res.header('Allow', 'GET, POST, OPTIONS, PUT, DELETE');
    next();
});

app.use('/users', users);
app.use('/twitter', twitter);
app.use('/tiktok', tiktok);



const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_DATABASE
});

app.get ("/h", (req, res) => {
    res.send("Hello World");
});
// LOGIN
app.post("/login", (req, res) => {
    const username = req.body.username;
    const password = req.body.password;
    db.query(
        "SELECT * FROM users WHERE username = ?;",
        username,
        (err, result) => {
            if (err) {
                console.log(err)
                res.send({ message: "Ocurrió un error, intentalo más tarde!" });
            }
            if (result.length > 0) {

                bcrypt.compare(password, result[0].password, (error, response) => {
                    if (response) {
                        const accessToken = jwt.sign({ id: result[0].user_id, username: result[0].username, type: result[0].type }, process.env.SECRET_JWT, { expiresIn: 86400 }); //24 hours
                        res.send({ tokenCTF: accessToken, messageSuccess: "Acceso Exitoso!" });

                    } else {
                        res.send({ message: "El usuario y contraseña no coinciden" });
                    }
                });
            } else {
                res.send({ message: "El usuario no existe!" });
            }
        }
    );
});


//SERVER
httpServer.listen(8080,process.env.SERVER_HOST,() => {
    console.log(`Running HTTP at http://${process.env.SERVER_HOST}:${process.env.PORT}/`);
})
/*httpsServer.listen(3001,process.env.SERVER_HOST,() => {
    console.log(`Running HTTP at https://${process.env.SERVER_HOST}:443/`);
})
*/
